# CRAMPS

**Competitive Reinforcement for Attractor-biased Multi-agent Plasticity in Shared substrates**

A multi-agent model of how structural inequality emerges in shared, modifiable graphs under selective forgetting.

Author: Manuel Rodrigo De la Barra Chávez · Investigador Independiente · Lima, Perú

---

## The one-sentence finding

In systems where agents competitively modify a shared graph through Hebbian reinforcement, structural inequality is non-monotonic in the decay rate λ, peaking at λ ≈ 0.3 — and this emerges even when all agents share identical scoring policies, suggesting the driver is goal-position under selective forgetting, not policy asymmetry.

---

## Repository structure

```
core/                model definition
  graph.py           graph construction, PageRank attractors
  agents.py          agent archetypes and scoring function
  walks.py           trajectory sampling
  plasticity.py      Hebbian update, decay, pruning, Gini

eval/                experiments
  run_experiments.py     Exp 1 — static strategy comparison
  run_plasticity.py      Exp 2 — plasticity dynamics / convergence
  run_phase_analysis.py  Exp 3 — phase diagram (THE robust result)
  run_counterfactual.py  Exp 4 — head-start counterfactual
  run_kill_test.py       Exp 5 + 6 — kill test and reward variants
  run_full.py            full pipeline
  stats.py               Mann-Whitney, Cohen's d

cramps_experiments.pdf   full experimental supplement
```

## Experiments and their evidential strength

| # | Experiment | Result | Strength |
|---|-----------|--------|----------|
| 1 | Static strategy comparison | archetypes behave distinctly | foundational |
| 2 | Plasticity dynamics | Gini converges to stable 0.196 | solid |
| 3 | Phase diagram (315 runs) | non-monotonic, peak λ≈0.3, Gini=0.387 | **strong** |
| 4 | Counterfactual head-start | gap widens +4.2% | suggestive |
| 5 | Kill test (policy homogeneity) | ΔGini=0.001 | null, low power |
| 6 | Reward function transitions | winner depends on reward | preliminary |

See `cramps_experiments.pdf` for full detail on each.

## Reproducing

```bash
pip install networkx sentence-transformers scipy numpy matplotlib
python eval/run_phase_analysis.py    # the central result
python eval/run_kill_test.py         # the adversarial test
```

All experiments use base seed 42 for exact reproducibility.

## Honest caveats

- The kill test (Exp 5) is a **null result under limited statistical power** (12 seeds). It shows policy asymmetry is not *necessary*, not that the conditions are equivalent.
- There is a known **circularity**: the centroid-seeking agent aligns with the coherence reward by construction. This is named, not hidden.
- Generalization to real knowledge graphs requires validation at N ∈ {50, 100, 200}.

## License

CC-BY 4.0
