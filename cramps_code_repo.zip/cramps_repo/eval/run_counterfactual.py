"""
CRAMPS v0.7 — Counterfactual Experiment
=========================================

Question: does the conformist dominate because of its POLICY
or because of PATH DEPENDENCY (it reaches the centroid first)?

Design:
  Condition 1 — simultaneous start (current v0.7)
  Condition 2 — disruptive head start (K epochs alone before others join)
  Condition 3 — conformist head start (K epochs alone before others join)

If conformist still dominates in Condition 2: POLICY matters.
If disruptive dominates in Condition 2:        PATH DEPENDENCY matters.

This is the minimum experiment needed before any causal claim.

Usage:
    python eval/run_counterfactual.py --mode demo
    python eval/run_counterfactual.py --corpus corpus_300.json --n 100
"""

import sys
import json
import random
import argparse
from pathlib import Path

import numpy as np
from tqdm import tqdm
import networkx as nx
from scipy.spatial.distance import cosine as cosine_dist

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from core.graph import build_graph, compute_attractors
from core.plasticity import decay_graph, normalize_weights
from core.agents import make_agents
from eval.run_ecology import (
    walk_agent, path_coherence, path_goal_proximity,
    competitive_update, EPOCHS, WALK_LENGTH, SIM_THRESHOLD,
    ETA, LAMBDA, NORMALIZE_EVERY, CRYSTAL_THRESHOLD, AGENT_COLORS
)
from eval.run_experiments import segment, DEMO_STORIES

OUTPUTS_DIR = PROJECT_ROOT / "outputs"
HEAD_START  = 10   # epochs the "head start" agent runs alone


# ─────────────────────────────────────────────
# CORE: one ecology run with a chosen condition
# ─────────────────────────────────────────────

def run_condition(units, embeddings, condition: str,
                  epochs: int = EPOCHS) -> dict | None:
    """
    condition:
      'simultaneous'   — all agents start at epoch 0
      'disruptive_hs'  — disruptive runs alone for HEAD_START epochs, then others join
      'conformist_hs'  — conformist runs alone for HEAD_START epochs, then others join
    """
    G      = build_graph(units, embeddings, threshold=SIM_THRESHOLD)
    if len(G.nodes) < 3 or len(G.edges) < 2:
        return None

    agents = make_agents(embeddings, G)
    agent_map = {a.name: a for a in agents}

    history = []

    for epoch in range(epochs):
        # Determine which agents are active this epoch
        if condition == "simultaneous":
            active = agents
        elif condition == "disruptive_hs":
            active = [agent_map["disruptive"]] if epoch < HEAD_START else agents
        elif condition == "conformist_hs":
            active = [agent_map["conformist"]] if epoch < HEAD_START else agents
        else:
            raise ValueError(f"Unknown condition: {condition}")

        attractors = compute_attractors(G)
        epoch_data = {"epoch": epoch, "agents": {}}

        for agent in active:
            start     = random.choice(list(G.nodes))
            path      = walk_agent(agent, start, G, attractors)
            coherence = path_coherence(path, G)
            goal_prox = path_goal_proximity(path, G, agent.goal_vector)
            competitive_update(G, path, reward=coherence, eta=ETA)

            epoch_data["agents"][agent.name] = {
                "coherence":      coherence,
                "goal_proximity": goal_prox,
                "active":         True,
            }

        # Mark inactive agents (head-start window)
        for agent in agents:
            if agent.name not in epoch_data["agents"]:
                epoch_data["agents"][agent.name] = {
                    "coherence":      None,
                    "goal_proximity": None,
                    "active":         False,
                }

        decay_graph(G, lambda_=LAMBDA)
        if (epoch + 1) % NORMALIZE_EVERY == 0 and len(G.edges) > 0:
            normalize_weights(G, method="global")

        # Gini
        weights = np.array([d["weight"] for _, _, d in G.edges(data=True)])
        epoch_data["gini"] = float(
            _gini(weights) if len(weights) > 1 else 0.0)

        history.append(epoch_data)

    return {"condition": condition, "history": history,
            "agent_names": [a.name for a in agents]}


def _gini(w: np.ndarray) -> float:
    w = np.sort(np.abs(w))
    n = len(w)
    return float((2 * np.sum(np.arange(1, n+1) * w) / (n * w.sum() + 1e-12)) - (n+1)/n)


# ─────────────────────────────────────────────
# STORY RUNNER (3 conditions per story)
# ─────────────────────────────────────────────

def run_counterfactual_story(text: str, model, story_id: int = 0,
                              epochs: int = EPOCHS) -> dict | None:
    units = segment(text)
    if len(units) < 4:
        return None

    embeddings = model.encode(units, show_progress_bar=False)
    norms      = np.linalg.norm(embeddings, axis=1, keepdims=True) + 1e-12
    embeddings = embeddings / norms

    results = {}
    for condition in ["simultaneous", "disruptive_hs", "conformist_hs"]:
        r = run_condition(units, embeddings, condition, epochs=epochs)
        if r:
            results[condition] = r

    if len(results) < 3:
        return None

    return {"story_id": story_id, "conditions": results}


# ─────────────────────────────────────────────
# AGGREGATION
# ─────────────────────────────────────────────

def aggregate_counterfactual(all_results: list[dict]) -> dict:
    conditions   = ["simultaneous", "disruptive_hs", "conformist_hs"]
    agent_names  = ["conformist", "disruptive", "opportunist"]
    metrics      = ["coherence", "goal_proximity"]

    # Only look at final N epochs to compare post-head-start dynamics
    compare_window = EPOCHS - HEAD_START

    agg = {
        cond: {
            agent: {m: [] for m in metrics}
            for agent in agent_names
        }
        for cond in conditions
    }

    for r in all_results:
        for cond, data in r["conditions"].items():
            # Epochs after head start phase
            post_hs = [e for e in data["history"]
                       if e["epoch"] >= HEAD_START]
            for snap in post_hs:
                for agent in agent_names:
                    a_data = snap["agents"].get(agent, {})
                    for m in metrics:
                        v = a_data.get(m)
                        if v is not None:
                            agg[cond][agent][m].append(v)

    # Reduce to means
    out = {}
    for cond in conditions:
        out[cond] = {}
        for agent in agent_names:
            out[cond][agent] = {}
            for m in metrics:
                vals = agg[cond][agent][m]
                out[cond][agent][m] = float(np.mean(vals)) if vals else 0.0

    return out


# ─────────────────────────────────────────────
# VERDICT: policy vs path dependency
# ─────────────────────────────────────────────

def print_verdict(agg: dict, n_stories: int):
    print("\n" + "="*72)
    print(f"{'CRAMPS — Counterfactual Analysis':^72}")
    print(f"{'n stories: ' + str(n_stories):^72}")
    print(f"{'head start window: ' + str(HEAD_START) + ' epochs':^72}")
    print("="*72)

    conditions = ["simultaneous", "disruptive_hs", "conformist_hs"]
    labels     = {
        "simultaneous":  "Simultaneous start",
        "disruptive_hs": f"Disruptive head start ({HEAD_START} ep alone)",
        "conformist_hs": f"Conformist head start ({HEAD_START} ep alone)",
    }

    print(f"\n  Goal proximity (post head-start epochs):\n")
    print(f"  {'Agent':<14}", end="")
    for c in conditions:
        print(f"  {labels[c][:22]:>22}", end="")
    print()
    print(f"  {'─'*80}")

    for agent in ["conformist", "disruptive", "opportunist"]:
        print(f"  {agent:<14}", end="")
        for c in conditions:
            v = agg[c][agent]["goal_proximity"]
            print(f"  {v:>22.4f}", end="")
        print()

    print(f"\n  Verdict:")

    # Key comparison: who wins goal_proximity in each condition?
    for c in conditions:
        prox   = {a: agg[c][a]["goal_proximity"] for a in ["conformist", "disruptive", "opportunist"]}
        winner = max(prox, key=prox.get)
        print(f"    {labels[c]}: dominant = {winner} ({prox[winner]:.4f})")

    # The causal question
    sim_dom    = max(agg["simultaneous"],    key=lambda a: agg["simultaneous"][a]["goal_proximity"])
    dis_hs_dom = max(agg["disruptive_hs"],   key=lambda a: agg["disruptive_hs"][a]["goal_proximity"])
    con_hs_dom = max(agg["conformist_hs"],   key=lambda a: agg["conformist_hs"][a]["goal_proximity"])

    print(f"\n  Causal interpretation:")
    if sim_dom == "conformist" and dis_hs_dom == "conformist":
        print("  → POLICY dominant: conformist wins even when disruptive has head start.")
        print("    Agent scoring bias (W_ATTRACTOR) is causally responsible.")
        print("    Path dependency is secondary.")
    elif sim_dom == "conformist" and dis_hs_dom != "conformist":
        print("  → PATH DEPENDENCY dominant: disruptive can win with head start.")
        print("    Early graph colonization determines dominance, not policy quality.")
        print("    CAUTION: the 'ideology as topology' claim needs qualification.")
    else:
        print("  → Mixed or inconclusive. Check n_stories and head_start length.")

    print("="*72 + "\n")


# ─────────────────────────────────────────────
# PLOT
# ─────────────────────────────────────────────

def plot_counterfactual(agg: dict, outdir: str = "outputs"):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import os
    os.makedirs(outdir, exist_ok=True)

    conditions  = ["simultaneous", "disruptive_hs", "conformist_hs"]
    cond_labels = ["Simultaneous", "Disruptive HS", "Conformist HS"]
    agent_names = ["conformist", "disruptive", "opportunist"]

    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    fig.suptitle(f"CRAMPS — Counterfactual (head start = {HEAD_START} epochs)", fontsize=13)

    x      = np.arange(len(conditions))
    width  = 0.25
    colors = [AGENT_COLORS[n] for n in agent_names]

    for ax_idx, metric in enumerate(["coherence", "goal_proximity"]):
        ax = axes[ax_idx]
        for i, (agent, color) in enumerate(zip(agent_names, colors)):
            vals = [agg[c][agent][metric] for c in conditions]
            bars = ax.bar(x + i * width - width, vals, width,
                          label=agent, color=color, edgecolor="white")
            for bar, v in zip(bars, vals):
                ax.text(bar.get_x() + bar.get_width()/2,
                        bar.get_height() + 0.002,
                        f"{v:.3f}", ha="center", va="bottom", fontsize=8)

        ax.set_xticks(x)
        ax.set_xticklabels(cond_labels, fontsize=10)
        ax.set_title(metric.replace("_", " ").title())
        ax.legend(fontsize=9)
        ax.set_ylim(0, min(1.0, ax.get_ylim()[1] * 1.2))
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)

    plt.tight_layout()
    outpath = f"{outdir}/cramps_counterfactual.png"
    plt.savefig(outpath, dpi=200, bbox_inches="tight")
    plt.close()
    print(f"✓ Counterfactual plot → {outpath}")
    return outpath


# ─────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode",       choices=["demo", "corpus"], default="demo")
    parser.add_argument("--corpus",     type=str)
    parser.add_argument("--n",          type=int, default=60)
    parser.add_argument("--epochs",     type=int, default=EPOCHS)
    parser.add_argument("--head-start", type=int, default=HEAD_START)
    parser.add_argument("--seed",       type=int, default=42)
    args = parser.parse_args()

    random.seed(args.seed)
    np.random.seed(args.seed)
    OUTPUTS_DIR.mkdir(exist_ok=True)

    from sentence_transformers import SentenceTransformer
    print(f"Loading model...")
    model = SentenceTransformer("all-MiniLM-L6-v2")

    if args.mode == "demo":
        stories = DEMO_STORIES
    else:
        with open(args.corpus) as f:
            stories = json.load(f)
        if len(stories) > args.n:
            stories = random.sample(stories, args.n)

    hs = args.head_start
    print(f"Mode: {args.mode.upper()} — {len(stories)} stories, "
          f"{args.epochs} epochs, head start = {hs}")

    all_results = []
    for i, story in enumerate(tqdm(stories, desc="Counterfactual")):
        r = run_counterfactual_story(story, model, story_id=i,
                                      epochs=args.epochs)
        if r:
            all_results.append(r)

    print(f"\n✓ {len(all_results)} stories processed")

    out = OUTPUTS_DIR / "cramps_counterfactual_results.json"
    with open(out, "w") as f:
        json.dump(all_results, f, indent=2)

    agg = aggregate_counterfactual(all_results)
    plot_counterfactual(agg, str(OUTPUTS_DIR))
    print_verdict(agg, len(all_results))


if __name__ == "__main__":
    main()
