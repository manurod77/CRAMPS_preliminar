"""
eval/stats.py — CRAMPS v0.5
Statistical significance testing.
Uses Mann-Whitney U (non-parametric) as primary test —
more robust than t-test for small samples.
t-test included as secondary for reviewers who expect it.
"""

import numpy as np
from scipy.stats import mannwhitneyu, ttest_ind


METRICS = ["topic_coherence", "loop_score", "diversity"]


def compare(agg: dict, metric: str) -> dict:
    baseline = np.array(agg["baseline"][metric])
    ablation = np.array(agg["ablation"][metric])
    cramps   = np.array(agg["cramps"][metric])

    # Mann-Whitney U: non-parametric, robust for n < 30
    u_stat_c, p_mw_c = mannwhitneyu(cramps, baseline, alternative="two-sided")
    u_stat_a, p_mw_a = mannwhitneyu(ablation, baseline, alternative="two-sided")

    # Welch's t-test as secondary
    t_c, p_t_c = ttest_ind(cramps, baseline, equal_var=False)
    t_a, p_t_a = ttest_ind(ablation, baseline, equal_var=False)

    def effect_size(a, b):
        """Cohen's d"""
        pooled = np.sqrt((np.std(a)**2 + np.std(b)**2) / 2)
        return float((np.mean(a) - np.mean(b)) / (pooled + 1e-12))

    return {
        "metric":           metric,
        "n":                len(baseline),
        "baseline_mean":    float(np.mean(baseline)),
        "baseline_std":     float(np.std(baseline)),
        "ablation_mean":    float(np.mean(ablation)),
        "ablation_std":     float(np.std(ablation)),
        "cramps_mean":      float(np.mean(cramps)),
        "cramps_std":       float(np.std(cramps)),
        # CRAMPS vs baseline
        "cramps_vs_baseline": {
            "delta":    float(np.mean(cramps) - np.mean(baseline)),
            "cohen_d":  effect_size(cramps, baseline),
            "p_mannwhitney": float(p_mw_c),
            "p_ttest":       float(p_t_c),
            "significant_p05": bool(p_mw_c < 0.05),
        },
        # ablation vs baseline (isolates scoring structure contribution)
        "ablation_vs_baseline": {
            "delta":    float(np.mean(ablation) - np.mean(baseline)),
            "cohen_d":  effect_size(ablation, baseline),
            "p_mannwhitney": float(p_mw_a),
            "p_ttest":       float(p_t_a),
            "significant_p05": bool(p_mw_a < 0.05),
        },
    }


def run_stats(agg: dict) -> list[dict]:
    return [compare(agg, m) for m in METRICS]


def print_stats_table(stats: list[dict]):
    """Pretty-print for terminal."""
    print("\n" + "="*72)
    print(f"{'CRAMPS v0.5 — Statistical Summary':^72}")
    print("="*72)

    for s in stats:
        m = s["metric"].replace("_", " ").upper()
        print(f"\n  {m}  (n={s['n']})")
        print(f"  {'Condition':<14} {'Mean':>8} {'Std':>7}")
        print(f"  {'─'*32}")
        for cond in ["baseline", "ablation", "cramps"]:
            mean = s[f"{cond}_mean"]
            std  = s[f"{cond}_std"]
            print(f"  {cond:<14} {mean:>8.4f} {std:>7.4f}")

        cb = s["cramps_vs_baseline"]
        sig = "✓ p<0.05" if cb["significant_p05"] else "✗ ns"
        print(f"\n  CRAMPS vs baseline │ Δ={cb['delta']:+.4f}"
              f"  d={cb['cohen_d']:+.3f}"
              f"  p(MW)={cb['p_mannwhitney']:.4f}  {sig}")

        ab = s["ablation_vs_baseline"]
        sig_a = "✓ p<0.05" if ab["significant_p05"] else "✗ ns"
        print(f"  Ablation vs base   │ Δ={ab['delta']:+.4f}"
              f"  d={ab['cohen_d']:+.3f}"
              f"  p(MW)={ab['p_mannwhitney']:.4f}  {sig_a}")

    print("\n" + "="*72)
    print("  Note: Mann-Whitney U (two-sided), Welch t-test as secondary.")
    print("  Cohen d: |d|<0.2 negligible, 0.2–0.5 small, 0.5–0.8 medium, >0.8 large")
    print("="*72 + "\n")
