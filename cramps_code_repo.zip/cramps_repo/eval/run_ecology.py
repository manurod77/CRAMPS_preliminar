"""
CRAMPS v0.7 — Multi-Agent Trajectory Ecology
=============================================

N agents with different goals and ideological biases navigate
a shared graph, each modifying it via competitive Hebbian plasticity.

Reinforcement is proportional to path quality (topic coherence),
so agents that produce better paths reinforce more strongly.

Hypothesis:
  - Conformist dominates structurally (high coherence → strong reinforcement)
  - Disruptive carves peripheral territory (low reinforcement but exclusive paths)
  - Opportunist free-rides but gets crowded out if conformist dominates

New metrics:
  - Gini coefficient of edge weights (inequality / oligarchy)
  - Agent path overlap (KL divergence between trajectory distributions)
  - Hegemonic node detection (PageRank > 2× mean)
  - Lock-in epoch (when edge weight variance stabilizes)
  - Agent territory (fraction of crystallized edges owned exclusively)

Usage:
    python eval/run_ecology.py --mode demo
    python eval/run_ecology.py --corpus corpus_300.json --n 100
"""

import sys
import json
import random
import argparse
from pathlib import Path

import numpy as np
from tqdm import tqdm
from scipy.spatial.distance import cosine as cosine_dist
import networkx as nx

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from core.graph import build_graph, compute_attractors
from core.walks import _candidates, _softmax, _entropy, NarrativeState
from core.plasticity import update_graph, decay_graph, normalize_weights
from core.agents import Agent, make_agents
from eval.run_experiments import segment, DEMO_STORIES


# ─────────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────────

MODEL_NAME    = "all-MiniLM-L6-v2"
EPOCHS        = 40
WALK_LENGTH   = 8
SIM_THRESHOLD = 0.35
ETA           = 0.05
LAMBDA        = 0.01
NORMALIZE_EVERY = 5
CRYSTAL_THRESHOLD = 0.5
OUTPUTS_DIR   = PROJECT_ROOT / "outputs"


# ─────────────────────────────────────────────
# AGENT WALK
# ─────────────────────────────────────────────

def walk_agent(agent: Agent, start: int, G: nx.Graph,
               attractors: dict, length: int = WALK_LENGTH) -> list[int]:
    path  = [start]
    state = np.zeros(G.nodes[start]["embedding"].shape)

    for _ in range(length - 1):
        cands = _candidates(path[-1], G)
        if not cands:
            break
        scores = [agent.score(c, path[-1], G, attractors, agent.goal_vector)
                  for c in cands]
        probs  = _softmax(scores, temp=agent.temperature)
        nxt    = int(np.random.choice(cands, p=probs))
        path.append(nxt)

    return path


# ─────────────────────────────────────────────
# PATH METRICS
# ─────────────────────────────────────────────

def path_coherence(path: list[int], G: nx.Graph) -> float:
    embs     = np.array([G.nodes[n]["embedding"] for n in path])
    centroid = embs.mean(axis=0)
    return float(np.mean([1 - cosine_dist(e, centroid) for e in embs]))


def path_loop(path: list[int]) -> float:
    return float(1 - len(set(path)) / len(path))


def path_goal_proximity(path: list[int], G: nx.Graph,
                         goal: np.ndarray) -> float:
    """Mean cosine similarity of path nodes to agent goal."""
    if np.linalg.norm(goal) < 1e-8:
        return 0.0
    embs = [G.nodes[n]["embedding"] for n in path]
    return float(np.mean([1 - cosine_dist(e, goal) for e in embs]))


# ─────────────────────────────────────────────
# ECOLOGY METRICS (shared graph state)
# ─────────────────────────────────────────────

def gini(weights: np.ndarray) -> float:
    """Gini coefficient of edge weight distribution. 0=equal, 1=monopoly."""
    if len(weights) < 2:
        return 0.0
    w = np.sort(np.abs(weights))
    n = len(w)
    return float((2 * np.sum(np.arange(1, n + 1) * w) / (n * w.sum() + 1e-12)) - (n + 1) / n)


def hegemonic_nodes(G: nx.Graph, multiplier: float = 2.0) -> list[int]:
    """Nodes with PageRank > multiplier × mean PageRank."""
    if len(G.edges) == 0:
        return []
    pr   = nx.pagerank(G, weight="weight")
    mean = np.mean(list(pr.values()))
    return [n for n, v in pr.items() if v > multiplier * mean]


def agent_territory(paths_by_agent: dict, G: nx.Graph) -> dict:
    """
    For each crystal edge (w > CRYSTAL_THRESHOLD), which agent
    traversed it most? Returns exclusive ownership fraction per agent.
    """
    crystal_edges = [(u, v) for u, v, d in G.edges(data=True)
                     if d["weight"] > CRYSTAL_THRESHOLD]
    if not crystal_edges:
        return {name: 0.0 for name in paths_by_agent}

    edge_counts = {name: {e: 0 for e in crystal_edges}
                   for name in paths_by_agent}

    for name, paths in paths_by_agent.items():
        for path in paths:
            for i in range(len(path) - 1):
                e = (min(path[i], path[i+1]), max(path[i], path[i+1]))
                if e in edge_counts[name]:
                    edge_counts[name][e] += 1

    territory = {}
    for name in paths_by_agent:
        owned = sum(1 for e in crystal_edges
                    if edge_counts[name][e] == max(
                        edge_counts[n][e] for n in paths_by_agent))
        territory[name] = float(owned / len(crystal_edges))

    return territory


def lock_in_epoch(variance_history: list[float],
                  window: int = 5, tol: float = 0.001) -> int | None:
    """Epoch when edge weight variance stops changing significantly."""
    for i in range(window, len(variance_history)):
        segment_var = np.var(variance_history[i-window:i])
        if segment_var < tol:
            return i - window
    return None


# ─────────────────────────────────────────────
# COMPETITIVE HEBBIAN UPDATE
# ─────────────────────────────────────────────

def competitive_update(G: nx.Graph, path: list[int],
                        reward: float, eta: float = ETA):
    """
    Reinforce proportional to reward (topic coherence).
    Better paths → stronger structural imprint.
    """
    for i in range(len(path) - 1):
        a, b = path[i], path[i + 1]
        e_a  = G.nodes[a]["embedding"]
        e_b  = G.nodes[b]["embedding"]
        sim  = float(1.0 - cosine_dist(e_a, e_b))
        delta = eta * reward * max(sim, 0.01)

        if G.has_edge(a, b):
            G[a][b]["weight"] = min(G[a][b]["weight"] + delta, 3.0)
        else:
            G.add_edge(a, b, weight=min(delta, 3.0))


# ─────────────────────────────────────────────
# SINGLE STORY ECOLOGY RUN
# ─────────────────────────────────────────────

def run_ecology_story(text: str, model, story_id: int = 0,
                       epochs: int = EPOCHS) -> dict | None:
    from sentence_transformers import SentenceTransformer

    units = segment(text)
    if len(units) < 4:
        return None

    embeddings = model.encode(units, show_progress_bar=False)
    norms      = np.linalg.norm(embeddings, axis=1, keepdims=True) + 1e-12
    embeddings = embeddings / norms

    G = build_graph(units, embeddings, threshold=SIM_THRESHOLD)
    if len(G.nodes) < 3 or len(G.edges) < 2:
        return None

    agents = make_agents(embeddings, G)

    history      = []
    weight_vars  = []
    paths_by_agent = {a.name: [] for a in agents}

    for epoch in range(epochs):
        attractors = compute_attractors(G)

        epoch_data = {
            "epoch": epoch,
            "n_edges": len(G.edges),
            "agents": {}
        }

        # Each agent walks, gets evaluated, reinforces
        for agent in agents:
            start = random.choice(list(G.nodes))
            path  = walk_agent(agent, start, G, attractors)
            paths_by_agent[agent.name].append(path)

            coherence = path_coherence(path, G)
            loop      = path_loop(path)
            goal_prox = path_goal_proximity(path, G, agent.goal_vector)

            # Competitive reinforcement: reward = coherence
            competitive_update(G, path, reward=coherence)

            epoch_data["agents"][agent.name] = {
                "coherence":      coherence,
                "loop_score":     loop,
                "goal_proximity": goal_prox,
            }

        # Shared decay
        decay_graph(G, lambda_=LAMBDA)
        if (epoch + 1) % NORMALIZE_EVERY == 0 and len(G.edges) > 0:
            normalize_weights(G, method="global")

        # Ecology metrics
        weights = np.array([d["weight"] for _, _, d in G.edges(data=True)])
        weight_vars.append(float(np.var(weights)) if len(weights) > 0 else 0.0)

        epoch_data["gini"]           = gini(weights)
        epoch_data["crystal_edges"]  = int(np.sum(weights > CRYSTAL_THRESHOLD))
        epoch_data["n_hegemonic"]    = len(hegemonic_nodes(G))
        epoch_data["w_mean"]         = float(np.mean(weights)) if len(weights) > 0 else 0.0
        epoch_data["w_std"]          = float(np.std(weights))  if len(weights) > 0 else 0.0

        history.append(epoch_data)

    # Final snapshot
    territory   = agent_territory(paths_by_agent, G)
    lock_epoch  = lock_in_epoch(weight_vars)

    return {
        "story_id":    story_id,
        "n_units":     len(units),
        "epochs":      epochs,
        "history":     history,
        "territory":   territory,
        "lock_in_epoch": lock_epoch,
        "agent_names": [a.name for a in agents],
    }


# ─────────────────────────────────────────────
# AGGREGATION
# ─────────────────────────────────────────────

def aggregate_ecology(all_results: list[dict]) -> dict:
    n_epochs = EPOCHS
    agent_names = all_results[0]["agent_names"]

    curves = {
        "gini":          [[] for _ in range(n_epochs)],
        "crystal_edges": [[] for _ in range(n_epochs)],
        "n_hegemonic":   [[] for _ in range(n_epochs)],
        "agents": {
            name: {
                "coherence":      [[] for _ in range(n_epochs)],
                "loop_score":     [[] for _ in range(n_epochs)],
                "goal_proximity": [[] for _ in range(n_epochs)],
            }
            for name in agent_names
        }
    }

    territory_agg = {name: [] for name in agent_names}
    lock_ins      = []

    for r in all_results:
        if r.get("lock_in_epoch") is not None:
            lock_ins.append(r["lock_in_epoch"])
        for name, frac in r.get("territory", {}).items():
            territory_agg[name].append(frac)

        for snap in r["history"]:
            e = snap["epoch"]
            if e >= n_epochs:
                continue
            curves["gini"][e].append(snap["gini"])
            curves["crystal_edges"][e].append(snap["crystal_edges"])
            curves["n_hegemonic"][e].append(snap["n_hegemonic"])
            for name in agent_names:
                if name in snap["agents"]:
                    for metric in ["coherence", "loop_score", "goal_proximity"]:
                        curves["agents"][name][metric][e].append(
                            snap["agents"][name][metric])

    def mean_curve(lst_of_lists):
        return [float(np.mean(v)) if v else 0.0 for v in lst_of_lists]

    agg = {
        "gini":          mean_curve(curves["gini"]),
        "crystal_edges": mean_curve(curves["crystal_edges"]),
        "n_hegemonic":   mean_curve(curves["n_hegemonic"]),
        "territory":     {name: float(np.mean(territory_agg[name]))
                          if territory_agg[name] else 0.0
                          for name in agent_names},
        "lock_in_mean":  float(np.mean(lock_ins)) if lock_ins else None,
        "lock_in_n":     len(lock_ins),
        "agents": {
            name: {
                metric: mean_curve(curves["agents"][name][metric])
                for metric in ["coherence", "loop_score", "goal_proximity"]
            }
            for name in agent_names
        }
    }

    return agg


# ─────────────────────────────────────────────
# VISUALIZATION
# ─────────────────────────────────────────────

AGENT_COLORS = {
    "conformist":  "#1D9E75",
    "disruptive":  "#D85A30",
    "opportunist": "#7F77DD",
}


def plot_ecology(agg: dict, outdir: str = "outputs"):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import os
    os.makedirs(outdir, exist_ok=True)

    epochs     = list(range(EPOCHS))
    agent_names = list(agg["agents"].keys())
    fig, axes  = plt.subplots(2, 3, figsize=(14, 8))
    fig.suptitle("CRAMPS v0.7 — Multi-Agent Ecology", fontsize=14)

    # ── 1. Gini coefficient ──
    ax = axes[0, 0]
    ax.plot(epochs, agg["gini"], color="#555", linewidth=2)
    ax.set_title("Gini — edge weight inequality")
    ax.set_xlabel("epoch")
    ax.set_ylabel("Gini")
    ax.set_ylim(0, 1)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

    # ── 2. Hegemonic nodes ──
    ax = axes[0, 1]
    ax.plot(epochs, agg["n_hegemonic"], color="#333", linewidth=2)
    ax.set_title("Hegemonic nodes (PR > 2× mean)")
    ax.set_xlabel("epoch")
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

    # ── 3. Agent topic coherence ──
    ax = axes[0, 2]
    for name in agent_names:
        ax.plot(epochs, agg["agents"][name]["coherence"],
                color=AGENT_COLORS[name], linewidth=2, label=name)
    ax.set_title("Topic coherence per agent")
    ax.set_xlabel("epoch")
    ax.legend(fontsize=9)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

    # ── 4. Goal proximity ──
    ax = axes[1, 0]
    for name in agent_names:
        ax.plot(epochs, agg["agents"][name]["goal_proximity"],
                color=AGENT_COLORS[name], linewidth=2, label=name)
    ax.set_title("Goal proximity (narrative territory)")
    ax.set_xlabel("epoch")
    ax.legend(fontsize=9)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

    # ── 5. Crystal edge territory (bar) ──
    ax = axes[1, 1]
    names  = list(agg["territory"].keys())
    fracs  = [agg["territory"][n] for n in names]
    colors = [AGENT_COLORS[n] for n in names]
    bars   = ax.bar(names, fracs, color=colors, edgecolor="white")
    for bar, frac in zip(bars, fracs):
        ax.text(bar.get_x() + bar.get_width() / 2,
                bar.get_height() + 0.01,
                f"{frac:.2f}", ha="center", va="bottom", fontsize=10)
    ax.set_title("Crystal edge territory (final)")
    ax.set_ylabel("fraction owned")
    ax.set_ylim(0, 1.1)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

    # ── 6. Loop score ──
    ax = axes[1, 2]
    for name in agent_names:
        ax.plot(epochs, agg["agents"][name]["loop_score"],
                color=AGENT_COLORS[name], linewidth=2, label=name)
    ax.set_title("Loop score (narrative recurrence)")
    ax.set_xlabel("epoch")
    ax.legend(fontsize=9)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

    plt.tight_layout()
    outpath = f"{outdir}/cramps_ecology.png"
    plt.savefig(outpath, dpi=200, bbox_inches="tight")
    plt.close()
    print(f"✓ Ecology plot → {outpath}")
    return outpath


# ─────────────────────────────────────────────
# SUMMARY PRINT
# ─────────────────────────────────────────────

def print_ecology_summary(agg: dict, n_stories: int):
    print("\n" + "="*72)
    print(f"{'CRAMPS v0.7 — Ecology Summary':^72}")
    print(f"{'n stories: ' + str(n_stories):^72}")
    print("="*72)

    print(f"\n  Graph inequality (Gini)")
    print(f"    epoch 0  = {agg['gini'][0]:.4f}")
    print(f"    epoch {EPOCHS-1} = {agg['gini'][-1]:.4f}  (Δ={agg['gini'][-1]-agg['gini'][0]:+.4f})")

    print(f"\n  Hegemonic nodes (final): {agg['n_hegemonic'][-1]:.1f}")

    if agg["lock_in_mean"] is not None:
        print(f"  Lock-in epoch: {agg['lock_in_mean']:.1f}  ({agg['lock_in_n']} stories converged)")
    else:
        print(f"  Lock-in: not detected in {EPOCHS} epochs")

    print(f"\n  {'Agent':<14} {'Coherence':>10} {'Goal prox':>10} {'Territory':>10}")
    print(f"  {'─'*48}")
    for name in agg["agents"]:
        coh  = agg["agents"][name]["coherence"][-1]
        prox = agg["agents"][name]["goal_proximity"][-1]
        terr = agg["territory"].get(name, 0.0)
        print(f"  {name:<14} {coh:>10.4f} {prox:>10.4f} {terr:>10.3f}")

    print(f"\n  Hypothesis check:")

    # H_conformist: highest final coherence?
    cohs = {n: agg["agents"][n]["coherence"][-1] for n in agg["agents"]}
    dominant = max(cohs, key=cohs.get)
    print(f"  Structural dominance (highest coherence): {dominant}")

    # H_disruptive: highest goal proximity?
    proxs = {n: agg["agents"][n]["goal_proximity"][-1] for n in agg["agents"]}
    most_goal = max(proxs, key=proxs.get)
    print(f"  Territory formation (highest goal proximity): {most_goal}")

    terr_leader = max(agg["territory"], key=agg["territory"].get)
    print(f"  Crystal edge ownership: {terr_leader} ({agg['territory'][terr_leader]:.2f})")

    gini_rise = agg["gini"][-1] - agg["gini"][0]
    print(f"  Gini rise: {gini_rise:+.4f} "
          f"({'inequality grew → oligarchic' if gini_rise > 0.05 else 'relatively stable'})")

    print("="*72 + "\n")


# ─────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode",   choices=["demo", "corpus"], default="demo")
    parser.add_argument("--corpus", type=str)
    parser.add_argument("--n",      type=int, default=100)
    parser.add_argument("--epochs", type=int, default=EPOCHS)
    parser.add_argument("--seed",   type=int, default=42)
    args = parser.parse_args()

    random.seed(args.seed)
    np.random.seed(args.seed)
    OUTPUTS_DIR.mkdir(exist_ok=True)

    from sentence_transformers import SentenceTransformer
    print(f"Loading model: {MODEL_NAME}")
    model = SentenceTransformer(MODEL_NAME)

    if args.mode == "demo":
        stories = DEMO_STORIES
        print(f"Mode: DEMO — {len(stories)} stories, {args.epochs} epochs")
    else:
        with open(args.corpus) as f:
            stories = json.load(f)
        if len(stories) > args.n:
            stories = random.sample(stories, args.n)
        print(f"Mode: CORPUS — {len(stories)} stories, {args.epochs} epochs")

    all_results = []
    for i, story in enumerate(tqdm(stories, desc="Ecology")):
        r = run_ecology_story(story, model, story_id=i, epochs=args.epochs)
        if r:
            all_results.append(r)

    print(f"\n✓ {len(all_results)} stories processed")

    out = OUTPUTS_DIR / "cramps_ecology_results.json"
    with open(out, "w") as f:
        json.dump(all_results, f, indent=2)
    print(f"✓ Results → {out}")

    agg = aggregate_ecology(all_results)
    plot_ecology(agg, str(OUTPUTS_DIR))
    print_ecology_summary(agg, len(all_results))

    agg_out = OUTPUTS_DIR / "cramps_ecology_agg.json"
    with open(agg_out, "w") as f:
        json.dump(agg, f, indent=2)
    print(f"✓ Aggregated → {agg_out}\n")


if __name__ == "__main__":
    main()
