"""
CRAMPS v0.6 — Plasticity Experiment
=====================================

Runs the dynamic graph experiment:
    for each epoch:
        sample path (CRAMPS or baseline)
        evaluate metrics
        update graph (Hebbian)
        decay graph
        snapshot structural state

Tests:
    H6 — Structural drift: CRAMPS graph diverges progressively from baseline
    H7 — Narrative crystallization: stable high-weight clusters emerge over time

Usage:
    python eval/run_plasticity.py --mode demo
    python eval/run_plasticity.py --mode rocstories --file path/to/rocstories.csv
"""

import sys
import os
import re
import json
import copy
import random
import argparse
from pathlib import Path

import numpy as np
from tqdm import tqdm
from sentence_transformers import SentenceTransformer
import networkx as nx

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from core.graph import build_graph, compute_attractors
from core.walks import NarrativeState, walk_cramps, walk_baseline
from core.plasticity import (
    update_graph, decay_graph, normalize_weights,
    graph_snapshot, structural_drift, tda_h1_persistence
)
from eval.run_experiments import segment, DEMO_STORIES


# ─────────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────────

MODEL_NAME    = "all-MiniLM-L6-v2"
EPOCHS        = 30       # plasticity iterations per story
WALK_LENGTH   = 8
SIM_THRESHOLD = 0.35
ETA           = 0.05     # Hebbian learning rate
LAMBDA        = 0.01     # decay rate
NORMALIZE_EVERY = 5      # normalize weights every N epochs
OUTPUTS_DIR   = PROJECT_ROOT / "outputs"


# ─────────────────────────────────────────────
# SINGLE STORY — PLASTICITY RUN
# ─────────────────────────────────────────────

def run_plasticity_story(text: str, model: SentenceTransformer,
                          story_id: int = 0, epochs: int = EPOCHS,
                          condition: str = "cramps") -> dict | None:
    units = segment(text)
    if len(units) < 4:
        return None

    embeddings = model.encode(units, show_progress_bar=False)
    norms = np.linalg.norm(embeddings, axis=1, keepdims=True) + 1e-12
    embeddings = embeddings / norms

    G = build_graph(units, embeddings, threshold=SIM_THRESHOLD)
    if len(G.nodes) < 3 or len(G.edges) < 2:
        return None

    dim  = embeddings.shape[1]
    goal = embeddings.mean(axis=0)

    # Baseline PageRank for drift measurement
    pr_baseline = nx.pagerank(G, weight="weight") if len(G.edges) > 0 else {}

    history = []
    tda_history = []

    for epoch in range(epochs):
        attractors = compute_attractors(G)
        start = random.choice(list(G.nodes))
        state = NarrativeState(dim=dim, goal=goal)

        if condition == "cramps":
            path = walk_cramps(start, G, state, attractors, length=WALK_LENGTH)
        else:
            path = walk_baseline(start, G, length=WALK_LENGTH)

        # Walk metrics
        path_embs = np.array([G.nodes[n]["embedding"] for n in path])
        centroid  = path_embs.mean(axis=0)
        from scipy.spatial.distance import cosine as cosine_dist
        topic_coh = float(np.mean([1 - cosine_dist(e, centroid) for e in path_embs]))
        loop      = float(1 - len(set(path)) / len(path))

        # Structural snapshot BEFORE update
        snap = graph_snapshot(G, epoch)
        snap["topic_coherence"] = topic_coh
        snap["loop_score"]      = loop
        snap["drift_from_init"] = structural_drift(G, pr_baseline)

        history.append(snap)

        # TDA every 5 epochs (expensive)
        if epoch % 5 == 0:
            tda = tda_h1_persistence(G)
            tda["epoch"] = epoch
            tda_history.append(tda)

        # Hebbian update
        update_graph(G, path, eta=ETA)

        # Decay
        decay_graph(G, lambda_=LAMBDA)

        # Periodic normalization
        if (epoch + 1) % NORMALIZE_EVERY == 0 and len(G.edges) > 0:
            normalize_weights(G, method="global")

    return {
        "story_id":  story_id,
        "condition": condition,
        "n_units":   len(units),
        "epochs":    epochs,
        "history":   history,
        "tda":       tda_history,
    }


# ─────────────────────────────────────────────
# COMPARISON: CRAMPS vs BASELINE plasticity
# ─────────────────────────────────────────────

def run_comparison(text: str, model: SentenceTransformer,
                   story_id: int = 0) -> dict | None:
    units = segment(text)
    if len(units) < 4:
        return None

    results = {}
    for cond in ["cramps", "baseline"]:
        r = run_plasticity_story(text, model, story_id=story_id,
                                  condition=cond)
        if r:
            results[cond] = r

    if len(results) < 2:
        return None

    return {"story_id": story_id, "conditions": results}


# ─────────────────────────────────────────────
# AGGREGATE DRIFT CURVE
# ─────────────────────────────────────────────

def aggregate_drift_curves(all_results: list[dict]) -> dict:
    """
    Average drift, crystallization, and coherence curves across stories.
    """
    n_epochs = EPOCHS
    curves = {
        cond: {
            "drift":        [[] for _ in range(n_epochs)],
            "crystal_edges":[[] for _ in range(n_epochs)],
            "topic_coh":    [[] for _ in range(n_epochs)],
            "loop_score":   [[] for _ in range(n_epochs)],
            "hub_entropy":  [[] for _ in range(n_epochs)],
        }
        for cond in ["cramps", "baseline"]
    }

    for r in all_results:
        for cond, data in r["conditions"].items():
            for snap in data["history"]:
                e = snap["epoch"]
                if e < n_epochs:
                    curves[cond]["drift"][e].append(snap["drift_from_init"])
                    curves[cond]["crystal_edges"][e].append(snap["crystal_edges"])
                    curves[cond]["topic_coh"][e].append(snap["topic_coherence"])
                    curves[cond]["loop_score"][e].append(snap["loop_score"])
                    curves[cond]["hub_entropy"][e].append(snap["hub_entropy"])

    # reduce to means
    agg = {}
    for cond in ["cramps", "baseline"]:
        agg[cond] = {}
        for metric, epochdata in curves[cond].items():
            agg[cond][metric] = [
                float(np.mean(v)) if v else 0.0
                for v in epochdata
            ]

    return agg


# ─────────────────────────────────────────────
# VISUALIZATION
# ─────────────────────────────────────────────

def plot_plasticity(agg: dict, outdir: str = "outputs"):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import os
    os.makedirs(outdir, exist_ok=True)

    epochs = list(range(EPOCHS))
    colors = {"cramps": "#e84040", "baseline": "#aaaaaa"}

    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    fig.suptitle("CRAMPS v0.6 — Graph Plasticity", fontsize=14)

    plots = [
        ("drift",         "Structural Drift (KL from init)",   axes[0, 0]),
        ("crystal_edges", "Crystallized Edges (w > 0.5)",       axes[0, 1]),
        ("topic_coh",     "Topic Coherence",                   axes[1, 0]),
        ("loop_score",    "Loop Score (narrative recurrence)", axes[1, 1]),
    ]

    for metric, title, ax in plots:
        for cond in ["cramps", "baseline"]:
            vals = agg[cond][metric]
            ax.plot(epochs, vals, color=colors[cond], linewidth=2,
                    label=cond.capitalize())
            ax.fill_between(epochs, [v * 0.9 for v in vals],
                            [v * 1.1 for v in vals],
                            color=colors[cond], alpha=0.10)

        ax.set_title(title, fontsize=11)
        ax.set_xlabel("epoch")
        ax.legend(fontsize=9)
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)

    plt.tight_layout()
    outpath = f"{outdir}/cramps_plasticity.png"
    plt.savefig(outpath, dpi=200, bbox_inches="tight")
    plt.close()
    print(f"✓ Plasticity plot → {outpath}")
    return outpath


def plot_tda_summary(all_results: list[dict], outdir: str = "outputs"):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import os
    os.makedirs(outdir, exist_ok=True)

    # Collect TDA snapshots per condition
    tda_data = {"cramps": {}, "baseline": {}}
    for r in all_results:
        for cond, data in r["conditions"].items():
            for snap in data.get("tda", []):
                e = snap["epoch"]
                if e not in tda_data[cond]:
                    tda_data[cond][e] = []
                tda_data[cond][e].append(snap.get("loops", 0))

    if not any(tda_data[c] for c in tda_data):
        return None

    fig, ax = plt.subplots(figsize=(6, 4))
    colors = {"cramps": "#e84040", "baseline": "#aaaaaa"}

    for cond in ["cramps", "baseline"]:
        epochs = sorted(tda_data[cond].keys())
        means  = [np.mean(tda_data[cond][e]) for e in epochs]
        ax.plot(epochs, means, marker="o", color=colors[cond],
                linewidth=2, label=cond.capitalize())

    ax.set_title("H7 — Narrative Loops (TDA H₁ over epochs)", fontsize=12)
    ax.set_xlabel("epoch")
    ax.set_ylabel("persistent H₁ loops")
    ax.legend()
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

    plt.tight_layout()
    outpath = f"{outdir}/cramps_tda_h1.png"
    plt.savefig(outpath, dpi=200, bbox_inches="tight")
    plt.close()
    print(f"✓ TDA plot → {outpath}")
    return outpath


# ─────────────────────────────────────────────
# STATS SUMMARY
# ─────────────────────────────────────────────

def print_plasticity_summary(agg: dict, all_results: list[dict]):
    print("\n" + "="*68)
    print(f"{'CRAMPS v0.6 — Plasticity Summary':^68}")
    print(f"{'n stories: ' + str(len(all_results)):^68}")
    print("="*68)

    metrics = ["drift", "crystal_edges", "topic_coh", "loop_score"]
    labels  = ["Structural drift", "Crystal edges", "Topic coherence", "Loop score"]

    for metric, label in zip(metrics, labels):
        c_final = agg["cramps"][metric][-1]
        b_final = agg["baseline"][metric][-1]
        c_init  = agg["cramps"][metric][0]
        delta   = c_final - c_init
        diff    = c_final - b_final

        print(f"\n  {label}")
        print(f"    CRAMPS    epoch 0={c_init:.4f}  → epoch {EPOCHS-1}={c_final:.4f}  (Δ={delta:+.4f})")
        print(f"    Baseline  epoch {EPOCHS-1}={b_final:.4f}")
        print(f"    CRAMPS vs baseline at final epoch: {diff:+.4f}")

    print("\n" + "="*68)
    print("  H6 (Structural drift): does CRAMPS drift more than baseline?")
    h6_cramps   = agg["cramps"]["drift"][-1]
    h6_baseline = agg["baseline"]["drift"][-1]
    if h6_cramps > h6_baseline:
        print(f"  → SUPPORTED: CRAMPS drift ({h6_cramps:.4f}) > baseline ({h6_baseline:.4f})")
    else:
        print(f"  → NOT SUPPORTED: CRAMPS drift ({h6_cramps:.4f}) ≤ baseline ({h6_baseline:.4f})")

    print("  H7 (Crystallization): do crystal edges grow over time?")
    c_init  = agg["cramps"]["crystal_edges"][0]
    c_final = agg["cramps"]["crystal_edges"][-1]
    if c_final > c_init:
        print(f"  → SUPPORTED: crystal edges grew from {c_init:.1f} to {c_final:.1f}")
    else:
        print(f"  → NOT SUPPORTED: crystal edges {c_init:.1f} → {c_final:.1f}")
    print("="*68 + "\n")


# ─────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode",   choices=["demo", "rocstories"], default="demo")
    parser.add_argument("--file",   type=str)
    parser.add_argument("--n",      type=int, default=100)
    parser.add_argument("--epochs", type=int, default=EPOCHS)
    parser.add_argument("--seed",   type=int, default=42)
    args = parser.parse_args()

    random.seed(args.seed)
    np.random.seed(args.seed)
    OUTPUTS_DIR.mkdir(exist_ok=True)

    print(f"Loading model: {MODEL_NAME}")
    model = SentenceTransformer(MODEL_NAME)

    if args.mode == "demo":
        stories = DEMO_STORIES
        print(f"Mode: DEMO — {len(stories)} stories, {args.epochs} epochs each")
    else:
        from eval.run_experiments import load_rocstories
        stories = load_rocstories(args.file, n=args.n)
        print(f"Mode: ROCStories — {len(stories)} stories, {args.epochs} epochs each")

    all_results = []
    for i, story in enumerate(tqdm(stories, desc="Plasticity experiments")):
        result = run_comparison(story, model, story_id=i)
        if result:
            all_results.append(result)

    print(f"\n✓ {len(all_results)} stories processed")

    # Save raw results
    out_json = OUTPUTS_DIR / "cramps_plasticity_results.json"
    with open(out_json, "w") as f:
        json.dump(all_results, f, indent=2)
    print(f"✓ Results → {out_json}")

    # Aggregate and visualize
    agg = aggregate_drift_curves(all_results)
    plot_plasticity(agg, str(OUTPUTS_DIR))
    plot_tda_summary(all_results, str(OUTPUTS_DIR))
    print_plasticity_summary(agg, all_results)


if __name__ == "__main__":
    main()
