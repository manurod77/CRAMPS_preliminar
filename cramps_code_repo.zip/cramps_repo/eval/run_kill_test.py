"""
CRAMPS Kill Test
================
Question: Is W_ATTRACTOR asymmetry doing the work,
or is goal heterogeneity alone sufficient?

Condition A — current CRAMPS (heterogeneous scoring + goals)
Condition B — same scoring for all, only goals differ

If Gini(A) >> Gini(B): scoring is causal. CRAMPS lives.
If Gini(A) ≈ Gini(B): scoring doesn't matter. CRAMPS dies.

Also tests initialization dependence per condition:
  A should be initialization-invariant (deterministic)
  B should show stochastic dependence (like Savit 2016)
"""

import sys, json, random, math
from pathlib import Path
import numpy as np
import networkx as nx
from tqdm import tqdm
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))
OUTPUTS_DIR = PROJECT_ROOT / "outputs"

# ─── config ────────────────────────────────────────────────
N_NODES   = 20
K_REG     = 4
P_REWIRE  = 0.2
EPOCHS    = 80
N_SEEDS   = 15
ETA       = 0.05
WMAX      = 3.0
PRUNE     = 0.007
WALK_LEN  = 8
TOP_K     = 6

LAMBDA_RANGE = [round(x, 3) for x in np.arange(0.0, 0.51, 0.025)]

# ─── agent definitions ─────────────────────────────────────

# Condition A: heterogeneous scoring (current paper)
AGENTS_A = [
    dict(name="conformist",  wAttr=1.2, wNeed=0.7, wEnt=-0.5, temp=0.8,  goal="centroid"),
    dict(name="disruptive",  wAttr=0.2, wNeed=0.9, wEnt= 0.4, temp=1.5,  goal="peripheral"),
    dict(name="opportunist", wAttr=0.9, wNeed=0.3, wEnt=-0.1, temp=1.0,  goal="dominant"),
]

# Condition B: identical scoring, only goals differ (kill test)
# Using mean of the three agents' weights — no privileged policy
AGENTS_B = [
    dict(name="same-1",      wAttr=0.7, wNeed=0.6, wEnt=-0.1, temp=1.1,  goal="centroid"),
    dict(name="same-2",      wAttr=0.7, wNeed=0.6, wEnt=-0.1, temp=1.1,  goal="peripheral"),
    dict(name="same-3",      wAttr=0.7, wNeed=0.6, wEnt=-0.1, temp=1.1,  goal="dominant"),
]

COLORS = {"conformist": "#1D9E75", "disruptive": "#D85A30", "opportunist": "#7F77DD"}
COND_COLORS = {"A": "#e84040", "B": "#4a9eff"}


# ─── graph & simulation ────────────────────────────────────

def make_graph(seed):
    G = nx.watts_strogatz_graph(N_NODES, K_REG, P_REWIRE, seed=seed)
    rng = np.random.RandomState(seed)
    for u, v in G.edges():
        G[u][v]["weight"] = float(rng.uniform(0.1, 0.9))
    for node in G.nodes():
        vec = rng.randn(32)
        G.nodes[node]["embedding"] = vec / (np.linalg.norm(vec) + 1e-12)
    return G


def get_goal_node(gtype, G):
    if gtype == "centroid":
        embs = np.array([G.nodes[n]["embedding"] for n in G.nodes])
        centroid = embs.mean(axis=0)
        dists = [float(np.linalg.norm(G.nodes[n]["embedding"] - centroid))
                 for n in G.nodes]
        return int(np.argmin(dists))
    elif gtype == "peripheral":
        embs = np.array([G.nodes[n]["embedding"] for n in G.nodes])
        centroid = embs.mean(axis=0)
        dists = [float(np.linalg.norm(G.nodes[n]["embedding"] - centroid))
                 for n in G.nodes]
        return int(np.argmax(dists))
    else:  # dominant = highest degree
        return max(G.nodes, key=lambda n: G.degree(n))


def score_node(candidate, current, ag, G, attractors, goal_node):
    from scipy.spatial.distance import cosine as cdist
    sem  = float(1 - cdist(G.nodes[candidate]["embedding"],
                            G.nodes[current]["embedding"]))
    attr = float(attractors.get(candidate, 0.0))
    gvec = G.nodes[goal_node]["embedding"]
    need = float(1 - cdist(G.nodes[candidate]["embedding"], gvec))
    nbrs = list(G.neighbors(candidate))
    ws   = [G[candidate][nb]["weight"] for nb in nbrs]
    if ws:
        mw  = np.mean(ws)
        ent = float(np.sqrt(np.mean([(w-mw)**2 for w in ws])) / WMAX)
    else:
        ent = 0.0
    return 1.0*sem + ag["wAttr"]*attr + ag["wNeed"]*need + ag["wEnt"]*ent


def softmax(scores, temp):
    arr = np.array(scores) / temp
    arr -= arr.max()
    e = np.exp(arr)
    return e / (e.sum() + 1e-12)


def walk(start, ag, G, attractors, goal_node, length=WALK_LEN):
    path = [start]
    for _ in range(length - 1):
        nbrs = sorted(G.neighbors(path[-1]),
                      key=lambda n: G[path[-1]][n]["weight"], reverse=True)
        cands = nbrs[:TOP_K]
        if not cands:
            break
        scores = [score_node(c, path[-1], ag, G, attractors, goal_node)
                  for c in cands]
        probs  = softmax(scores, ag["temp"])
        path.append(int(np.random.choice(cands, p=probs)))
    return path


def path_coherence(path, G):
    from scipy.spatial.distance import cosine as cdist
    embs = [G.nodes[n]["embedding"] for n in path]
    c    = np.mean(embs, axis=0)
    return float(np.mean([1 - cdist(e, c) for e in embs]))


def gini(G):
    ws = np.array([d["weight"] for _,_,d in G.edges(data=True)])
    if len(ws) < 2:
        return 0.0
    ws = np.sort(np.abs(ws))
    n  = len(ws)
    return float((2*np.sum(np.arange(1,n+1)*ws)) / (n*ws.sum()+1e-12) - (n+1)/n)


def run_one(agents_def, lambda_, seed, epochs=EPOCHS):
    np.random.seed(seed); random.seed(seed)
    G = make_graph(seed)

    goal_nodes = [get_goal_node(ag["goal"], G) for ag in agents_def]
    starts     = [i % N_NODES for i in range(len(agents_def))]

    gini_hist  = []
    dom_counts = {ag["name"]: 0 for ag in agents_def}

    for epoch in range(epochs):
        attractors = nx.pagerank(G, weight="weight") if G.edges else {}

        paths = []
        for i, ag in enumerate(agents_def):
            p    = walk(starts[i], ag, G, attractors, goal_nodes[i])
            coh  = path_coherence(p, G)
            paths.append((p, coh))
            starts[i] = p[-1]

        # Hebbian update
        for (p, coh) in paths:
            for j in range(len(p)-1):
                a, b = p[j], p[j+1]
                k    = f"{min(a,b)}-{max(a,b)}"
                ew   = G[a][b]["weight"] if G.has_edge(a,b) else 0
                new  = min(ew + ETA * coh, WMAX)
                if G.has_edge(a,b):
                    G[a][b]["weight"] = new
                else:
                    G.add_edge(a, b, weight=new)

        # Decay + prune
        for u, v, d in list(G.edges(data=True)):
            d["weight"] *= (1 - lambda_)
        for u, v in [(u,v) for u,v,d in G.edges(data=True) if d["weight"]<PRUNE]:
            G.remove_edge(u, v)

        # Track who "owns" most recently visited node area
        coherences = [c for _,c in paths]
        winner = agents_def[int(np.argmax(coherences))]["name"]
        dom_counts[winner] += 1

        gini_hist.append(gini(G))

    return {
        "gini_final": gini_hist[-1] if gini_hist else 0.0,
        "gini_hist":  gini_hist,
        "dom_counts": dom_counts,
        "winner":     max(dom_counts, key=dom_counts.get),
    }


# ─── phase sweep comparison ────────────────────────────────

def sweep(agents_def, label):
    results = {}
    for lam in tqdm(LAMBDA_RANGE, desc=f"Condition {label}"):
        runs = [run_one(agents_def, lam, seed) for seed in range(N_SEEDS)]
        results[lam] = {
            "gini_mean": float(np.mean([r["gini_final"] for r in runs])),
            "gini_std":  float(np.std( [r["gini_final"] for r in runs])),
            "dominant_freq": {
                ag["name"]: float(np.mean([r["winner"]==ag["name"] for r in runs]))
                for ag in agents_def
            }
        }
    return results


# ─── counterfactual (K=0 vs K=50) per condition ────────────

def counterfactual_dominance(agents_def, lambda_=0.3, k_values=(0, 10, 50), n_texts=40):
    """
    Measures goal proximity disparity across K conditions.
    Proxy: mean final coherence ratio winner/loser.
    """
    from scipy.spatial.distance import cosine as cdist

    results = {}
    for K in k_values:
        diffs = []
        for seed in range(n_texts):
            np.random.seed(seed*7+13); random.seed(seed*7+13)
            G = make_graph(seed)
            goal_nodes = [get_goal_node(ag["goal"], G) for ag in agents_def]
            starts     = [i % N_NODES for i in range(len(agents_def))]
            attractors = nx.pagerank(G, weight="weight")

            # Head-start for agent index 1 (disruptive/same-2)
            for _ in range(K):
                p = walk(starts[1], agents_def[1], G, attractors, goal_nodes[1])
                for j in range(len(p)-1):
                    a,b = p[j], p[j+1]
                    if G.has_edge(a,b):
                        G[a][b]["weight"] = min(G[a][b]["weight"]+ETA*0.8, WMAX)
                    else:
                        G.add_edge(a,b,weight=ETA*0.8)
                for _,_,d in G.edges(data=True): d["weight"]*=(1-lambda_)
                starts[1] = p[-1]

            # Joint phase
            for _ in range(EPOCHS - K):
                attractors = nx.pagerank(G, weight="weight") if G.edges else {}
                cohs = []
                for i,ag in enumerate(agents_def):
                    p   = walk(starts[i], ag, G, attractors, goal_nodes[i])
                    cohs.append(path_coherence(p, G))
                    starts[i] = p[-1]
                    for j in range(len(p)-1):
                        a,b = p[j],p[j+1]
                        if G.has_edge(a,b):
                            G[a][b]["weight"] = min(G[a][b]["weight"]+ETA*cohs[-1], WMAX)
                        else:
                            G.add_edge(a,b,weight=ETA*cohs[-1])
                for _,_,d in G.edges(data=True): d["weight"]*=(1-lambda_)

            # Gap: agent 0 coherence - agent 1 coherence
            diffs.append(cohs[0] - cohs[1])

        results[K] = float(np.mean(diffs))
    return results


# ─── plot ──────────────────────────────────────────────────

def plot_results(sweep_A, sweep_B, cf_A, cf_B, verdict):
    fig, axes = plt.subplots(1, 3, figsize=(14, 4.5))
    fig.suptitle("CRAMPS Kill Test — Scoring asymmetry vs. goal asymmetry",
                 fontsize=13)

    lambdas = LAMBDA_RANGE

    # Panel 1: Phase curves
    ax = axes[0]
    for label, sw, color in [("A — heterogeneous scoring", sweep_A, "#e84040"),
                               ("B — identical scoring (kill)", sweep_B, "#4a9eff")]:
        means = [sw[l]["gini_mean"] for l in lambdas]
        stds  = [sw[l]["gini_std"]  for l in lambdas]
        ax.plot(lambdas, means, color=color, lw=2.2, label=label)
        ax.fill_between(lambdas,
                        [m-s for m,s in zip(means,stds)],
                        [m+s for m,s in zip(means,stds)],
                        alpha=0.13, color=color)
    # Mark peaks
    for sw, color in [(sweep_A,"#e84040"),(sweep_B,"#4a9eff")]:
        means = [sw[l]["gini_mean"] for l in lambdas]
        pi    = int(np.argmax(means))
        ax.scatter([lambdas[pi]], [means[pi]], color=color, s=60, zorder=4)
    ax.set_title("Phase diagram: Gini vs λ")
    ax.set_xlabel("decay rate λ")
    ax.set_ylabel("Gini")
    ax.set_ylim(0, 0.55)
    ax.legend(fontsize=8)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

    # Panel 2: Dominance in Condition B (should this be stochastic?)
    ax = axes[1]
    agent_names = [ag["name"] for ag in AGENTS_B]
    freqs = [np.mean([sweep_B[l]["dominant_freq"].get(name,0)
                      for l in lambdas]) for name in agent_names]
    cols  = ["#4a9eff", "#88bbff", "#bbddff"]
    bars  = ax.bar(agent_names, freqs, color=cols, edgecolor="white")
    ax.axhline(1/3, color="#999", linestyle="--", lw=1, alpha=0.6)
    ax.text(2.4, 1/3 + 0.01, "chance", fontsize=8, color="#999")
    for bar, v in zip(bars, freqs):
        ax.text(bar.get_x()+bar.get_width()/2, v+0.01,
                f"{v:.2f}", ha="center", fontsize=9)
    ax.set_title("Condition B: dominance\n(should be ≈1/3 if scoring doesn't matter)")
    ax.set_ylabel("fraction of epochs dominant")
    ax.set_ylim(0, 0.8)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

    # Panel 3: Counterfactual gap (K=0,10,50) for both conditions
    ax = axes[2]
    k_vals = sorted(cf_A.keys())
    ax.plot(k_vals, [cf_A[k] for k in k_vals], "o-", color="#e84040",
            lw=2.2, label="A — heterogeneous")
    ax.plot(k_vals, [cf_B[k] for k in k_vals], "s--", color="#4a9eff",
            lw=2.2, label="B — identical scoring")
    ax.axhline(0, color="#aaa", lw=0.8)
    ax.set_title("Coherence gap (agent 0 − agent 1)\nvs head-start K")
    ax.set_xlabel("head-start epochs K")
    ax.set_ylabel("Δ coherence")
    ax.legend(fontsize=8)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

    # Verdict box
    vcolor = "#1D9E75" if "LIVES" in verdict else ("#D85A30" if "DIES" in verdict else "#BA7517")
    fig.text(0.5, 0.02, verdict, ha="center", fontsize=11,
             color="white", weight="bold",
             bbox=dict(facecolor=vcolor, boxstyle="round,pad=0.4", edgecolor="none"))

    plt.tight_layout(rect=[0,0.08,1,1])
    outpath = OUTPUTS_DIR / "cramps_kill_test.png"
    plt.savefig(outpath, dpi=200, bbox_inches="tight")
    plt.close()
    return outpath


# ─── verdict logic ─────────────────────────────────────────

def compute_verdict(sweep_A, sweep_B, cf_A, cf_B):
    peak_A = max(sweep_A[l]["gini_mean"] for l in LAMBDA_RANGE)
    peak_B = max(sweep_B[l]["gini_mean"] for l in LAMBDA_RANGE)
    ratio  = (peak_A - peak_B) / (peak_A + 1e-6)

    gap_A_growth = cf_A.get(50, 0) - cf_A.get(0, 0)
    gap_B_growth = cf_B.get(50, 0) - cf_B.get(0, 0)

    lines = []
    lines.append(f"Gini peak A={peak_A:.3f}  B={peak_B:.3f}  ratio={ratio:.2f}")
    lines.append(f"CF gap growth A={gap_A_growth:+.3f}  B={gap_B_growth:+.3f}")

    if ratio > 0.25:
        verdict = f"✓ CRAMPS LIVES — scoring asymmetry adds {ratio*100:.0f}% more inequality than goal asymmetry alone"
    elif ratio > 0.10:
        verdict = f"△ PARTIAL — scoring adds modest effect ({ratio*100:.0f}%); goals do most of the work"
    else:
        verdict = f"✗ CRAMPS DIES — scoring asymmetry is not causal; goal heterogeneity suffices"

    return verdict, "\n".join(lines)


# ─── main ──────────────────────────────────────────────────

def main():
    OUTPUTS_DIR.mkdir(exist_ok=True)
    np.random.seed(42); random.seed(42)

    print("Phase sweep — Condition A (heterogeneous scoring)...")
    sweep_A = sweep(AGENTS_A, "A")

    print("Phase sweep — Condition B (identical scoring, kill test)...")
    sweep_B = sweep(AGENTS_B, "B")

    print("Counterfactual K=0,10,50 — Condition A...")
    cf_A = counterfactual_dominance(AGENTS_A, lambda_=0.3)

    print("Counterfactual K=0,10,50 — Condition B...")
    cf_B = counterfactual_dominance(AGENTS_B, lambda_=0.3)

    verdict, stats = compute_verdict(sweep_A, sweep_B, cf_A, cf_B)

    print("\n" + "="*68)
    print(f"{'CRAMPS KILL TEST — VERDICT':^68}")
    print("="*68)
    print(stats)
    print()
    print(verdict)
    print("="*68)

    outpath = plot_results(sweep_A, sweep_B, cf_A, cf_B, verdict)
    print(f"\n✓ Plot → {outpath}")

    with open(OUTPUTS_DIR / "kill_test_results.json", "w") as f:
        json.dump({
            "sweep_A": {str(k): v for k,v in sweep_A.items()},
            "sweep_B": {str(k): v for k,v in sweep_B.items()},
            "cf_A": {str(k): v for k,v in cf_A.items()},
            "cf_B": {str(k): v for k,v in cf_B.items()},
            "verdict": verdict, "stats": stats
        }, f, indent=2)


if __name__ == "__main__":
    main()
