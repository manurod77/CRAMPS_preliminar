"""
CRAMPS v0.6 — Full Pipeline Runner
=====================================
Runs both experiments (static comparison + plasticity)
on any JSON corpus file.

Usage:
    python eval/run_full.py --corpus corpus_300.json
    python eval/run_full.py --corpus corpus_300.json --skip-plasticity
"""

import sys
import json
import random
import argparse
from pathlib import Path

import numpy as np

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

OUTPUTS_DIR = PROJECT_ROOT / "outputs"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--corpus",           type=str, required=True)
    parser.add_argument("--n",                type=int, default=300)
    parser.add_argument("--epochs",           type=int, default=30)
    parser.add_argument("--seed",             type=int, default=42)
    parser.add_argument("--skip-plasticity",  action="store_true")
    args = parser.parse_args()

    random.seed(args.seed)
    np.random.seed(args.seed)
    OUTPUTS_DIR.mkdir(exist_ok=True)

    with open(args.corpus, "r") as f:
        stories = json.load(f)

    if len(stories) > args.n:
        stories = random.sample(stories, args.n)

    print(f"Corpus: {args.corpus} — {len(stories)} stories")

    # ── EXPERIMENT 1: static comparison (v0.5) ──────────────────────
    print("\n[1/2] Static comparison (baseline vs ablation vs CRAMPS)...")

    from sentence_transformers import SentenceTransformer
    model = SentenceTransformer("all-MiniLM-L6-v2")

    from eval.run_experiments import run_story
    from tqdm import tqdm

    static_results = []
    for i, story in enumerate(tqdm(stories, desc="Static")):
        r = run_story(story, model, story_id=i)
        if r:
            static_results.append(r)

    print(f"✓ {len(static_results)} stories processed")

    out = OUTPUTS_DIR / "cramps_results.json"
    with open(out, "w") as f:
        json.dump(static_results, f, indent=2)
    print(f"✓ Saved → {out}")

    from viz.plots import generate_all_plots
    plot_files, agg = generate_all_plots(str(out), str(OUTPUTS_DIR))

    from eval.stats import run_stats, print_stats_table
    stats = run_stats(agg)
    print_stats_table(stats)

    stats_out = OUTPUTS_DIR / "cramps_stats.json"
    with open(stats_out, "w") as f:
        json.dump(stats, f, indent=2)

    # ── EXPERIMENT 2: plasticity (v0.6) ─────────────────────────────
    if not args.skip_plasticity:
        print("\n[2/2] Plasticity experiment (Hebbian + decay)...")

        from eval.run_plasticity import run_comparison, aggregate_drift_curves
        from eval.run_plasticity import plot_plasticity, plot_tda_summary, print_plasticity_summary
        import eval.run_plasticity as rp
        rp.EPOCHS = args.epochs

        plasticity_results = []
        for i, story in enumerate(tqdm(stories, desc="Plasticity")):
            r = run_comparison(story, model, story_id=i)
            if r:
                plasticity_results.append(r)

        print(f"✓ {len(plasticity_results)} stories processed")

        out_p = OUTPUTS_DIR / "cramps_plasticity_results.json"
        with open(out_p, "w") as f:
            json.dump(plasticity_results, f, indent=2)
        print(f"✓ Saved → {out_p}")

        agg_p = aggregate_drift_curves(plasticity_results)
        plot_plasticity(agg_p, str(OUTPUTS_DIR))
        plot_tda_summary(plasticity_results, str(OUTPUTS_DIR))
        print_plasticity_summary(agg_p, plasticity_results)

    print("\n✓ All experiments complete.")
    print(f"  Outputs in: {OUTPUTS_DIR}/\n")


if __name__ == "__main__":
    main()
