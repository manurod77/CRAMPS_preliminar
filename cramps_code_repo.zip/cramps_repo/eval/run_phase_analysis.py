"""
CRAMPS — Phase Analysis on Synthetic Graphs
=============================================

MVP experiment proposed by peer review:
  "If monopoly persists on a perfectly symmetric graph under balanced
   initialization, topological capture is a property of the scoring
   function — not an artifact of corpus structure."

Design:
  - Synthetic regular graph (Watts-Strogatz) with RANDOM initial weights
    (no semantic bias from language embeddings)
  - Two agents in isolation to isolate the mechanism:
      Agent A (attractor): β=1.0, α=γ=δ=0  (follows PageRank only)
      Agent B (explorer):  δ=1.0, α=β=γ=0  (follows entropy only)
  - Sweep λ from 0.0 to 0.50 in steps of 0.025
  - Measure: Gini at convergence, convergence epoch, dominant agent

If Agent A (attractor) dominates under symmetric initialization and
random weights, reward-induced topological capture is confirmed as a
structural property of competitive Hebbian dynamics.

Usage:
    python eval/run_phase_analysis.py
    python eval/run_phase_analysis.py --n-nodes 30 --epochs 100 --seeds 20
"""

import sys
import json
import random
import argparse
from pathlib import Path
from itertools import product

import numpy as np
import networkx as nx
from tqdm import tqdm

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

OUTPUTS_DIR = PROJECT_ROOT / "outputs"


# ─────────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────────

N_NODES    = 20         # nodes per synthetic graph
K_REGULAR  = 4          # Watts-Strogatz k (nearest neighbors)
P_REWIRE   = 0.2        # Watts-Strogatz rewiring probability
WALK_LENGTH = 8
TOP_K      = 6
ETA        = 0.05
EPOCHS     = 80

LAMBDA_RANGE = [round(x, 3) for x in np.arange(0.0, 0.51, 0.025)]


# ─────────────────────────────────────────────
# SYNTHETIC GRAPH
# ─────────────────────────────────────────────

def make_synthetic_graph(n: int, k: int, p: float,
                          seed: int) -> nx.Graph:
    """
    Watts-Strogatz small-world graph with RANDOM edge weights.
    No semantic structure — eliminates corpus-bias confound.
    """
    G = nx.watts_strogatz_graph(n, k, p, seed=seed)
    rng = np.random.RandomState(seed)
    for u, v in G.edges():
        G[u][v]["weight"] = float(rng.uniform(0.1, 1.0))
    # Add random embedding (uniform sphere) to each node
    for node in G.nodes():
        vec = rng.randn(32)
        G.nodes[node]["embedding"] = vec / (np.linalg.norm(vec) + 1e-12)
    return G


# ─────────────────────────────────────────────
# PURE AGENTS
# ─────────────────────────────────────────────

def score_attractor(candidate: int, G: nx.Graph,
                    attractors: dict) -> float:
    """Agent A: β=1 only. Pure structural conformism."""
    return attractors.get(candidate, 0.0)


def score_explorer(candidate: int, G: nx.Graph) -> float:
    """Agent B: δ=1 only. Pure entropy seeking."""
    nbrs = list(G.neighbors(candidate))
    if not nbrs:
        return 0.0
    w = np.array([G[candidate][nb]["weight"] for nb in nbrs])
    w = w / (w.sum() + 1e-12)
    import math
    ent = -np.sum(w * np.log(w + 1e-12))
    return float(ent / (math.log(len(nbrs) + 1) + 1e-12))


def softmax(scores: list[float], temp: float = 1.0) -> np.ndarray:
    arr = np.array(scores, dtype=float) / temp
    arr -= arr.max()
    exp = np.exp(arr)
    return exp / (exp.sum() + 1e-12)


def walk(start: int, G: nx.Graph, agent: str,
          attractors: dict, length: int = WALK_LENGTH) -> list[int]:
    path = [start]
    for _ in range(length - 1):
        nbrs = sorted(G.neighbors(path[-1]),
                      key=lambda n: G[path[-1]][n]["weight"], reverse=True)
        cands = nbrs[:TOP_K]
        if not cands:
            break
        if agent == "attractor":
            scores = [score_attractor(c, G, attractors) for c in cands]
        else:
            scores = [score_explorer(c, G) for c in cands]
        probs  = softmax(scores)
        path.append(int(np.random.choice(cands, p=probs)))
    return path


# ─────────────────────────────────────────────
# METRICS
# ─────────────────────────────────────────────

def gini(G: nx.Graph) -> float:
    w = np.array([d["weight"] for _, _, d in G.edges(data=True)])
    if len(w) < 2:
        return 0.0
    w = np.sort(np.abs(w))
    n = len(w)
    return float((2 * np.sum(np.arange(1, n+1) * w) / (n * w.sum() + 1e-12)) - (n+1)/n)


def territory(G: nx.Graph, paths_a: list, paths_b: list,
               crystal_thresh: float = 0.5) -> tuple[float, float]:
    """Fraction of crystal edges owned by each agent."""
    crystal = [(min(u,v), max(u,v)) for u, v, d in G.edges(data=True)
               if d["weight"] > crystal_thresh]
    if not crystal:
        return 0.0, 0.0

    count_a = {e: 0 for e in crystal}
    count_b = {e: 0 for e in crystal}

    for path in paths_a:
        for i in range(len(path)-1):
            e = (min(path[i], path[i+1]), max(path[i], path[i+1]))
            if e in count_a:
                count_a[e] += 1

    for path in paths_b:
        for i in range(len(path)-1):
            e = (min(path[i], path[i+1]), max(path[i], path[i+1]))
            if e in count_b:
                count_b[e] += 1

    owned_a = sum(1 for e in crystal if count_a[e] >= count_b[e])
    owned_b = sum(1 for e in crystal if count_b[e] > count_a[e])
    return owned_a / len(crystal), owned_b / len(crystal)


def is_converged(gini_history: list[float], window: int = 8,
                  tol: float = 0.002) -> bool:
    if len(gini_history) < window:
        return False
    return float(np.std(gini_history[-window:])) < tol


# ─────────────────────────────────────────────
# SINGLE RUN
# ─────────────────────────────────────────────

def run_single(lambda_: float, seed: int,
               epochs: int = EPOCHS) -> dict:
    G = make_synthetic_graph(N_NODES, K_REGULAR, P_REWIRE, seed)

    paths_a, paths_b = [], []
    gini_history     = []
    conv_epoch       = None

    for epoch in range(epochs):
        attractors = nx.pagerank(G, weight="weight") if len(G.edges) > 0 \
                     else {n: 0.0 for n in G.nodes}

        start_a = random.choice(list(G.nodes))
        start_b = random.choice(list(G.nodes))

        path_a = walk(start_a, G, "attractor", attractors)
        path_b = walk(start_b, G, "explorer",  attractors)

        paths_a.append(path_a)
        paths_b.append(path_b)

        # Hebbian update (equal η for both agents — no reward differential)
        for path in [path_a, path_b]:
            for i in range(len(path)-1):
                a, b = path[i], path[i+1]
                if G.has_edge(a, b):
                    G[a][b]["weight"] = min(G[a][b]["weight"] + ETA, 3.0)
                else:
                    G.add_edge(a, b, weight=ETA)

        # Decay
        for u, v, data in G.edges(data=True):
            data["weight"] *= (1.0 - lambda_)
        weak = [(u, v) for u, v, d in G.edges(data=True) if d["weight"] < 0.005]
        G.remove_edges_from(weak)

        g = gini(G)
        gini_history.append(g)

        if conv_epoch is None and is_converged(gini_history):
            conv_epoch = epoch

    ta, tb = territory(G, paths_a, paths_b)

    return {
        "lambda":       lambda_,
        "seed":         seed,
        "gini_final":   gini_history[-1],
        "gini_init":    gini_history[0],
        "gini_delta":   gini_history[-1] - gini_history[0],
        "conv_epoch":   conv_epoch,
        "territory_a":  ta,
        "territory_b":  tb,
        "dominant":     "attractor" if ta > tb else "explorer",
        "n_edges_final": len(G.edges),
    }


# ─────────────────────────────────────────────
# PHASE SWEEP
# ─────────────────────────────────────────────

def run_phase_sweep(n_seeds: int = 10,
                     epochs: int = EPOCHS) -> list[dict]:
    all_results = []
    total = len(LAMBDA_RANGE) * n_seeds

    with tqdm(total=total, desc="Phase sweep") as pbar:
        for lambda_ in LAMBDA_RANGE:
            for seed in range(n_seeds):
                r = run_single(lambda_, seed, epochs=epochs)
                all_results.append(r)
                pbar.update(1)

    return all_results


def aggregate_phase(results: list[dict]) -> dict:
    by_lambda = {}
    for r in results:
        lam = r["lambda"]
        if lam not in by_lambda:
            by_lambda[lam] = []
        by_lambda[lam].append(r)

    lambdas     = sorted(by_lambda.keys())
    gini_means  = []
    gini_stds   = []
    conv_means  = []
    dom_a_frac  = []

    for lam in lambdas:
        rs = by_lambda[lam]
        gini_means.append(float(np.mean([r["gini_final"] for r in rs])))
        gini_stds.append(float(np.std([r["gini_final"]  for r in rs])))
        convs = [r["conv_epoch"] for r in rs if r["conv_epoch"] is not None]
        conv_means.append(float(np.mean(convs)) if convs else float("nan"))
        dom_a_frac.append(float(np.mean([1 if r["dominant"] == "attractor" else 0
                                          for r in rs])))

    return {
        "lambdas":      lambdas,
        "gini_means":   gini_means,
        "gini_stds":    gini_stds,
        "conv_means":   conv_means,
        "dom_a_frac":   dom_a_frac,
    }


# ─────────────────────────────────────────────
# VISUALIZATION
# ─────────────────────────────────────────────

def plot_phase(agg: dict, outdir: str = "outputs"):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import os
    os.makedirs(outdir, exist_ok=True)

    lambdas = agg["lambdas"]
    fig, axes = plt.subplots(1, 3, figsize=(14, 4))
    fig.suptitle("Phase Analysis — Synthetic Graph (no corpus bias)", fontsize=13)

    # ── Gini at convergence ──
    ax = axes[0]
    ax.plot(lambdas, agg["gini_means"], color="#333", linewidth=2)
    ax.fill_between(lambdas,
                    [m - s for m, s in zip(agg["gini_means"], agg["gini_stds"])],
                    [m + s for m, s in zip(agg["gini_means"], agg["gini_stds"])],
                    alpha=0.2, color="#333")
    ax.set_title("Gini at convergence vs λ")
    ax.set_xlabel("decay rate λ")
    ax.set_ylabel("Gini (mean ± std)")
    ax.set_ylim(0, 1)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

    # ── Convergence epoch ──
    ax = axes[1]
    valid = [(l, c) for l, c in zip(lambdas, agg["conv_means"])
             if not (isinstance(c, float) and c != c)]  # filter NaN
    if valid:
        lv, cv = zip(*valid)
        ax.plot(lv, cv, color="#555", linewidth=2, marker="o", markersize=4)
    ax.set_title("Convergence epoch vs λ")
    ax.set_xlabel("decay rate λ")
    ax.set_ylabel("epoch")
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

    # ── Attractor dominance fraction ──
    ax = axes[2]
    ax.bar(range(len(lambdas)), agg["dom_a_frac"],
           color=["#1D9E75" if f > 0.5 else "#D85A30" for f in agg["dom_a_frac"]],
           width=0.7)
    ax.axhline(0.5, color="#333", linestyle="--", linewidth=1, alpha=0.5)
    ax.set_title("Attractor dominance fraction")
    ax.set_xlabel("λ index")
    ax.set_ylabel("fraction (attractor wins)")
    ax.set_ylim(0, 1)
    ax.set_xticks(range(0, len(lambdas), 4))
    ax.set_xticklabels([f"{lambdas[i]:.2f}" for i in range(0, len(lambdas), 4)],
                        fontsize=8)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

    plt.tight_layout()
    outpath = f"{outdir}/cramps_phase_analysis.png"
    plt.savefig(outpath, dpi=200, bbox_inches="tight")
    plt.close()
    print(f"✓ Phase plot → {outpath}")
    return outpath


# ─────────────────────────────────────────────
# PRINT VERDICT
# ─────────────────────────────────────────────

def print_phase_verdict(agg: dict):
    lambdas    = agg["lambdas"]
    dom_frac   = agg["dom_a_frac"]
    gini_means = agg["gini_means"]

    print("\n" + "="*68)
    print(f"{'Phase Analysis — Verdict':^68}")
    print("="*68)

    # How often does attractor dominate?
    overall_dom = float(np.mean(dom_frac))
    print(f"\n  Attractor dominance (all λ): {overall_dom:.3f}")
    if overall_dom > 0.6:
        print("  → STRUCTURAL RESULT: attractor dominates across λ range")
        print("    Topological capture is a property of scoring, not corpus bias.")
    elif overall_dom > 0.4:
        print("  → MIXED: dominance depends on λ regime")
    else:
        print("  → Explorer dominates: high entropy wins in this regime")

    # Phase transition: where does Gini peak?
    peak_idx = int(np.argmax(gini_means))
    print(f"\n  Gini peaks at λ={lambdas[peak_idx]:.3f} → {gini_means[peak_idx]:.4f}")
    if peak_idx < len(lambdas) // 3:
        print("  → Low decay favors monopolization")
    elif peak_idx > 2 * len(lambdas) // 3:
        print("  → High decay needed for maximum inequality")
    else:
        print("  → Peak inequality at intermediate λ (competition + consolidation)")

    # λ=0 case (no forgetting)
    print(f"\n  λ=0.0 (no decay): Gini={gini_means[0]:.4f}, "
          f"attractor dom={dom_frac[0]:.2f}")
    print(f"  λ=0.5 (fast decay): Gini={gini_means[-1]:.4f}, "
          f"attractor dom={dom_frac[-1]:.2f}")

    print("\n" + "="*68 + "\n")


# ─────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--n-nodes", type=int, default=N_NODES)
    parser.add_argument("--epochs",  type=int, default=EPOCHS)
    parser.add_argument("--seeds",   type=int, default=10)
    parser.add_argument("--seed",    type=int, default=42)
    args = parser.parse_args()

    random.seed(args.seed)
    np.random.seed(args.seed)
    OUTPUTS_DIR.mkdir(exist_ok=True)

    print(f"Phase analysis: {len(LAMBDA_RANGE)} λ values × {args.seeds} seeds "
          f"= {len(LAMBDA_RANGE) * args.seeds} runs")
    print(f"Graph: Watts-Strogatz n={args.n_nodes}, k={K_REGULAR}, p={P_REWIRE}")
    print(f"Agents: pure attractor (β=1) vs pure explorer (δ=1)")
    print(f"Note: RANDOM initial weights — no corpus/embedding bias\n")

    results = run_phase_sweep(n_seeds=args.seeds, epochs=args.epochs)

    out = OUTPUTS_DIR / "cramps_phase_results.json"
    with open(out, "w") as f:
        json.dump(results, f, indent=2)
    print(f"✓ Raw results → {out}")

    agg = aggregate_phase(results)
    plot_phase(agg, str(OUTPUTS_DIR))
    print_phase_verdict(agg)

    agg_out = OUTPUTS_DIR / "cramps_phase_agg.json"
    with open(agg_out, "w") as f:
        json.dump(agg, f, indent=2)


if __name__ == "__main__":
    main()
