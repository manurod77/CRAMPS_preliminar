"""
CRAMPS v0.5 — Experiment Orchestrator
======================================

Runs controlled comparison:
    baseline semantic walk  vs
    CRAMPS ablation         vs
    full CRAMPS model

Outputs: JSON + plots + stats table

Usage:
    python eval/run_experiments.py --mode demo
    python eval/run_experiments.py --mode rocstories --file path/to/rocstories.csv --n 300
"""

import sys
import os
import re
import json
import random
import argparse
from pathlib import Path

import numpy as np
from tqdm import tqdm
from sentence_transformers import SentenceTransformer

# path resolution (works whether called from project root or eval/)
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from core.graph import build_graph, compute_attractors
from core.walks import (
    walk_baseline, walk_ablation, walk_cramps,
    NarrativeState, path_revisits
)
from scipy.spatial.distance import cosine as cosine_dist


# ─────────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────────

MODEL_NAME    = "all-MiniLM-L6-v2"
WALK_LENGTH   = 8
N_RUNS        = 5
SIM_THRESHOLD = 0.35
OUTPUTS_DIR   = PROJECT_ROOT / "outputs"
RESULTS_FILE  = OUTPUTS_DIR / "cramps_results.json"


# ─────────────────────────────────────────────
# TEXT PROCESSING
# ─────────────────────────────────────────────

def segment(text: str) -> list[str]:
    parts = re.split(r'(?<=[.!?])\s+', text.strip())
    return [p.strip() for p in parts if len(p.strip()) > 10]


# ─────────────────────────────────────────────
# METRICS
# ─────────────────────────────────────────────

def topic_coherence(path: list[int], G) -> float:
    embs = np.array([G.nodes[n]["embedding"] for n in path])
    centroid = embs.mean(axis=0)
    sims = [float(1.0 - cosine_dist(e, centroid)) for e in embs]
    return float(np.mean(sims))


def diversity(path: list[int], G) -> float:
    embs = [G.nodes[n]["embedding"] for n in path]
    dists = []
    for i in range(len(embs)):
        for j in range(i + 1, len(embs)):
            dists.append(float(cosine_dist(embs[i], embs[j])))
    return float(np.mean(dists)) if dists else 0.0


def loop_score(path: list[int]) -> float:
    return path_revisits(path)


def evaluate(path: list[int], G) -> dict:
    return {
        "topic_coherence": topic_coherence(path, G),
        "loop_score":      loop_score(path),
        "diversity":       diversity(path, G),
        "path_length":     len(path),
    }


# ─────────────────────────────────────────────
# STORY RUNNER
# ─────────────────────────────────────────────

def run_story(text: str, model: SentenceTransformer,
              story_id: int = 0) -> dict | None:

    units = segment(text)
    if len(units) < 4:
        return None

    embeddings = model.encode(units, show_progress_bar=False)
    norms = np.linalg.norm(embeddings, axis=1, keepdims=True) + 1e-12
    embeddings = embeddings / norms

    G = build_graph(units, embeddings, threshold=SIM_THRESHOLD)
    if len(G.nodes) < 3 or len(G.edges) < 2:
        return None

    attractors = compute_attractors(G)
    dim  = embeddings.shape[1]
    goal = embeddings.mean(axis=0)

    result = {
        "story_id": story_id,
        "n_nodes":  len(G.nodes),
        "n_edges":  len(G.edges),
        "conditions": {}
    }

    for condition in ["baseline", "ablation", "cramps"]:
        run_metrics = []
        for _ in range(N_RUNS):
            start = random.choice(list(G.nodes))
            state = NarrativeState(dim=dim, goal=goal)

            if condition == "baseline":
                path = walk_baseline(start, G, length=WALK_LENGTH)
            elif condition == "ablation":
                path = walk_ablation(start, G, state, length=WALK_LENGTH)
            else:
                path = walk_cramps(start, G, state, attractors, length=WALK_LENGTH)

            run_metrics.append(evaluate(path, G))

        # aggregate over runs
        agg = {k: float(np.mean([m[k] for m in run_metrics]))
               for k in run_metrics[0]}
        result["conditions"][condition] = agg

    return result


# ─────────────────────────────────────────────
# DATASETS
# ─────────────────────────────────────────────

DEMO_STORIES = [
    """Maria had always wanted to visit Paris. She saved money for three years.
    Finally she bought a plane ticket. She arrived in the city on a rainy morning.
    The Eiffel Tower was smaller than she imagined but more beautiful.
    She ate a croissant near the Seine and cried from happiness.""",

    """The dog kept barking at the fence. Tom went outside to check.
    He found a small child crying in the neighbor's yard.
    The child had fallen off a bike and hurt her knee.
    Tom called the parents and gave the child some water.
    The dog wagged its tail when the girl smiled again.""",

    """Every summer they returned to the lake house. The wooden dock was always
    rotten in one plank. His father never fixed it. He never fixed it either.
    Now his own son asked why the plank was still broken. He didn't know what to say.
    Some things stay broken so we remember who we were.""",

    """Ana started learning piano at forty. Everyone said it was too late.
    Her fingers were slow and her patience was thin. But she practiced every morning.
    Six months later she played a small piece for her daughter.
    Her daughter recorded it on her phone without asking. The video had three million views.""",

    """The job interview lasted twenty minutes. He had prepared for weeks.
    They asked one question he didn't expect: what failure taught him the most.
    He thought about the startup. He thought about his brother.
    He answered honestly. They called the next day. He didn't take the job.""",

    """She had not spoken to her mother in three years. The silence grew its own shape.
    At the funeral she arrived late and stood near the back.
    Her cousins looked at her. She looked at the floor.
    On the drive home she realized she could not remember the last thing she had said.""",

    """The night before the defense he deleted the entire third chapter.
    His advisor found out in the morning. They rewrote it together in four hours.
    He passed. She never told anyone she had written most of it.
    Five years later he cited her work in a keynote. He did not mention her name.""",

    """They met on the bus every Tuesday for two months. He read physics. She read poetry.
    One Tuesday she was not there. He waited two weeks before he stopped looking.
    She had moved cities. She still had his bookmark.""",
]


def load_rocstories(filepath: str, n: int = 300) -> list[str]:
    import csv
    stories = []
    with open(filepath, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        cols = ["sentence1", "sentence2", "sentence3", "sentence4", "sentence5"]
        for row in reader:
            story = " ".join(row[c] for c in cols if c in row)
            stories.append(story)
            if len(stories) >= n:
                break
    return stories


# ─────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=["demo", "rocstories"], default="demo")
    parser.add_argument("--file", type=str)
    parser.add_argument("--n",    type=int, default=300)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    random.seed(args.seed)
    np.random.seed(args.seed)

    OUTPUTS_DIR.mkdir(exist_ok=True)

    print(f"Loading model: {MODEL_NAME}")
    model = SentenceTransformer(MODEL_NAME)

    if args.mode == "demo":
        stories = DEMO_STORIES
        print(f"Mode: DEMO — {len(stories)} synthetic stories")
    else:
        if not args.file:
            raise ValueError("--file required for rocstories mode")
        stories = load_rocstories(args.file, n=args.n)
        print(f"Mode: ROCStories — {len(stories)} stories from {args.file}")

    all_results = []
    for i, story in enumerate(tqdm(stories, desc="Running experiments")):
        result = run_story(story, model, story_id=i)
        if result:
            all_results.append(result)

    print(f"\n✓ {len(all_results)} stories processed")

    # Save JSON
    with open(RESULTS_FILE, "w", encoding="utf-8") as f:
        json.dump(all_results, f, indent=2)
    print(f"✓ Results saved → {RESULTS_FILE}")

    # Plots
    from viz.plots import generate_all_plots
    plot_files, agg = generate_all_plots(str(RESULTS_FILE), str(OUTPUTS_DIR))
    print(f"✓ Plots saved → {OUTPUTS_DIR}/")
    for p in plot_files:
        print(f"   {p}")

    # Stats
    from eval.stats import run_stats, print_stats_table
    stats = run_stats(agg)
    print_stats_table(stats)

    stats_path = OUTPUTS_DIR / "cramps_stats.json"
    with open(stats_path, "w") as f:
        json.dump(stats, f, indent=2)
    print(f"✓ Stats saved → {stats_path}\n")


if __name__ == "__main__":
    main()
