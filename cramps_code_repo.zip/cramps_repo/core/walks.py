"""
core/walks.py — CRAMPS v0.5
Three walk strategies: baseline, ablation, full CRAMPS.
Plus NarrativeState and path utilities.
"""

import math
import numpy as np
import networkx as nx
from scipy.spatial.distance import cosine as cosine_dist


# ─────────────────────────────────────────────
# CRAMPS ENGINE WEIGHTS
# Selected on validation split; tune before scaling.
# ─────────────────────────────────────────────

W_SEMANTIC    =  1.0
W_ATTRACTOR   =  0.7
W_NEED        =  0.5
W_UNCERTAINTY = -0.3

DECAY_ALPHA = 0.7
TOP_K       = 10


# ─────────────────────────────────────────────
# NARRATIVE STATE
# ─────────────────────────────────────────────

class NarrativeState:
    """
    S_t = compressed narrative state
    S_{t+1} = α * S_t + (1-α) * embedding(v_t)
    """

    def __init__(self, dim: int, goal: np.ndarray | None = None):
        self.dim   = dim
        self.state = np.zeros(dim)
        self.goal  = goal if goal is not None else np.zeros(dim)

    def update(self, embedding: np.ndarray):
        self.state = DECAY_ALPHA * self.state + (1 - DECAY_ALPHA) * embedding

    def need_alignment(self, embedding: np.ndarray) -> float:
        if np.linalg.norm(self.goal) < 1e-8:
            return 0.0
        return float(1.0 - cosine_dist(embedding, self.goal))


# ─────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────

def _candidates(node: int, G: nx.Graph) -> list[int]:
    """Top-K neighbours by edge weight."""
    nbrs = sorted(G.neighbors(node),
                  key=lambda n: G[node][n]["weight"], reverse=True)
    return nbrs[:TOP_K]


def _softmax(scores: list[float], temp: float = 1.0) -> np.ndarray:
    arr = np.array(scores, dtype=float) / temp
    arr -= arr.max()
    exp = np.exp(arr)
    return exp / (exp.sum() + 1e-12)


def _entropy(node: int, G: nx.Graph) -> float:
    """Local entropy over neighbour weights — measures ambiguity."""
    nbrs = list(G.neighbors(node))
    if not nbrs:
        return 0.0
    w = np.array([G[node][nb]["weight"] for nb in nbrs])
    w = w / (w.sum() + 1e-12)
    ent = -np.sum(w * np.log(w + 1e-12))
    return float(ent / (math.log(len(nbrs) + 1) + 1e-12))


# ─────────────────────────────────────────────
# SCORING
# ─────────────────────────────────────────────

def _cramps_score(candidate: int, current: int,
                  G: nx.Graph, state: NarrativeState,
                  attractors: dict) -> float:
    emb_c    = G.nodes[candidate]["embedding"]
    emb_curr = G.nodes[current]["embedding"]

    semantic    = float(1.0 - cosine_dist(emb_c, emb_curr))
    attractor   = float(attractors.get(candidate, 0.0))
    need        = state.need_alignment(emb_c)
    uncertainty = _entropy(candidate, G)

    return (W_SEMANTIC    * semantic
          + W_ATTRACTOR   * attractor
          + W_NEED        * need
          + W_UNCERTAINTY * uncertainty)


# ─────────────────────────────────────────────
# WALKS
# ─────────────────────────────────────────────

def walk_baseline(start: int, G: nx.Graph, length: int = 8) -> list[int]:
    """Pure semantic walk — edge weight only."""
    path = [start]
    for _ in range(length - 1):
        cands = _candidates(path[-1], G)
        if not cands:
            break
        w = np.array([G[path[-1]][c]["weight"] for c in cands])
        probs = w / (w.sum() + 1e-12)
        path.append(int(np.random.choice(cands, p=probs)))
    return path


def walk_ablation(start: int, G: nx.Graph,
                  state: NarrativeState, length: int = 8) -> list[int]:
    """
    CRAMPS-minimal: Engine with only semantic term.
    Isolates contribution of attractor + need + uncertainty fields.
    """
    path = [start]
    state.update(G.nodes[start]["embedding"])
    for _ in range(length - 1):
        cands = _candidates(path[-1], G)
        if not cands:
            break
        scores = [float(1.0 - cosine_dist(G.nodes[c]["embedding"],
                                           G.nodes[path[-1]]["embedding"]))
                  for c in cands]
        probs = _softmax(scores)
        next_n = int(np.random.choice(cands, p=probs))
        path.append(next_n)
        state.update(G.nodes[next_n]["embedding"])
    return path


def walk_cramps(start: int, G: nx.Graph,
                state: NarrativeState, attractors: dict,
                length: int = 8) -> list[int]:
    """Full CRAMPS Engine walk."""
    path = [start]
    state.update(G.nodes[start]["embedding"])
    for _ in range(length - 1):
        cands = _candidates(path[-1], G)
        if not cands:
            break
        scores = [_cramps_score(c, path[-1], G, state, attractors)
                  for c in cands]
        probs = _softmax(scores)
        next_n = int(np.random.choice(cands, p=probs))
        path.append(next_n)
        state.update(G.nodes[next_n]["embedding"])
    return path


# ─────────────────────────────────────────────
# PATH UTILITIES
# ─────────────────────────────────────────────

def path_embedding(path: list[int], G: nx.Graph) -> np.ndarray:
    """Mean embedding of all nodes in path."""
    return np.mean([G.nodes[n]["embedding"] for n in path], axis=0)


def path_revisits(path: list[int]) -> float:
    """Fraction of revisited nodes. CRAMPS predicts higher values."""
    return 1.0 - len(set(path)) / len(path)
