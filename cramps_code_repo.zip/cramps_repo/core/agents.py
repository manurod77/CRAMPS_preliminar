"""
core/agents.py — CRAMPS v0.7
Agent archetypes for multi-agent trajectory ecology.

Each agent has:
  - goal_vector  : what narrative region it pursues  (Option A)
  - score_weights: its ideological navigation bias    (Option C)
  - temperature  : exploration sharpness

Three archetypes:
  conformist   — follows mainstream, avoids ambiguity
  disruptive   — seeks periphery, ignores established paths
  opportunist  — free-rides on dominant structure
"""

from dataclasses import dataclass, field
import numpy as np
import networkx as nx
from scipy.spatial.distance import cosine as cosine_dist


# ─────────────────────────────────────────────
# AGENT DEFINITION
# ─────────────────────────────────────────────

@dataclass
class Agent:
    name:        str
    goal_vector: np.ndarray         # narrative objective (A)
    w_semantic:  float = 1.0
    w_attractor: float = 0.7
    w_need:      float = 0.5
    w_uncertainty: float = -0.3
    temperature: float = 1.0
    color:       str   = "#888"     # for visualization

    def score(self, candidate: int, current: int,
              G: nx.Graph, attractors: dict,
              state_goal: np.ndarray) -> float:
        """CRAMPS Engine score using this agent's weights."""
        emb_c    = G.nodes[candidate]["embedding"]
        emb_curr = G.nodes[current]["embedding"]

        semantic    = float(1.0 - cosine_dist(emb_c, emb_curr))
        attractor   = float(attractors.get(candidate, 0.0))
        need        = float(1.0 - cosine_dist(emb_c, self.goal_vector)) \
                      if np.linalg.norm(self.goal_vector) > 1e-8 else 0.0
        uncertainty = _local_entropy(candidate, G)

        return (self.w_semantic    * semantic
              + self.w_attractor   * attractor
              + self.w_need        * need
              + self.w_uncertainty * uncertainty)


def _local_entropy(node: int, G: nx.Graph) -> float:
    import math
    nbrs = list(G.neighbors(node))
    if not nbrs:
        return 0.0
    w = np.array([G[node][nb]["weight"] for nb in nbrs])
    w = w / (w.sum() + 1e-12)
    ent = -np.sum(w * np.log(w + 1e-12))
    return float(ent / (math.log(len(nbrs) + 1) + 1e-12))


# ─────────────────────────────────────────────
# GOAL VECTOR CONSTRUCTORS
# ─────────────────────────────────────────────

def goal_centroid(embeddings: np.ndarray) -> np.ndarray:
    """Mean of all embeddings — mainstream narrative."""
    return embeddings.mean(axis=0)


def goal_peripheral(embeddings: np.ndarray) -> np.ndarray:
    """Embedding most distant from centroid — peripheral narrative."""
    centroid = embeddings.mean(axis=0)
    dists    = np.array([float(cosine_dist(e, centroid)) for e in embeddings])
    return embeddings[dists.argmax()]


def goal_dominant(embeddings: np.ndarray, G: nx.Graph) -> np.ndarray:
    """Embedding of highest-PageRank node — hegemonic attractor."""
    if len(G.edges) == 0:
        return embeddings.mean(axis=0)
    pr      = nx.pagerank(G, weight="weight")
    top_idx = max(pr, key=pr.get)
    return G.nodes[top_idx]["embedding"]


# ─────────────────────────────────────────────
# ARCHETYPE FACTORY
# ─────────────────────────────────────────────

def make_agents(embeddings: np.ndarray, G: nx.Graph) -> list[Agent]:
    """
    Instantiate the three archetypes for a given story graph.
    Goals are computed from this story's embedding space.
    """
    return [
        Agent(
            name        = "conformist",
            goal_vector = goal_centroid(embeddings),
            w_semantic  = 1.0,
            w_attractor = 1.2,   # ↑ follows established paths
            w_need      = 0.7,
            w_uncertainty = -0.5, # ↓ avoids ambiguous nodes
            temperature = 0.8,   # more focused
            color       = "#1D9E75",
        ),
        Agent(
            name        = "disruptive",
            goal_vector = goal_peripheral(embeddings),
            w_semantic  = 1.0,
            w_attractor = 0.2,   # ↓ ignores established paths
            w_need      = 0.9,   # ↑ strongly goal-directed
            w_uncertainty = +0.4, # ↑ seeks ambiguous nodes
            temperature = 1.5,   # more exploratory
            color       = "#D85A30",
        ),
        Agent(
            name        = "opportunist",
            goal_vector = goal_dominant(embeddings, G),
            w_semantic  = 1.0,
            w_attractor = 0.9,   # mostly follows structure
            w_need      = 0.3,   # ↓ weakly goal-directed
            w_uncertainty = -0.1,
            temperature = 1.0,
            color       = "#7F77DD",
        ),
    ]
