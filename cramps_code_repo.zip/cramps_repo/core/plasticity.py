"""
core/plasticity.py — CRAMPS v0.6
Graph plasticity: Hebbian strengthening + exponential decay + normalization.

Design choices:
  - Hebbian rule: w_ij += η · cosine_sim(i, j)  when edge (i,j) is traversed
  - Decay:        w_ij *= (1 - λ)               applied every epoch
  - Prune:        remove edges below θ_prune
  - Normalize:    soft-cap weights to [0, 1] to prevent monopolization
"""

import networkx as nx
import numpy as np
from scipy.spatial.distance import cosine as cosine_dist


# ─────────────────────────────────────────────
# DEFAULTS (all overridable per experiment)
# ─────────────────────────────────────────────

ETA     = 0.05   # Hebbian learning rate
LAMBDA  = 0.01   # decay rate per epoch
THETA   = 0.005  # prune threshold (below this → edge deleted)
W_MAX   = 3.0    # soft cap (prevents monopoly hubs)


# ─────────────────────────────────────────────
# HEBBIAN UPDATE
# ─────────────────────────────────────────────

def update_graph(G: nx.Graph, path: list[int],
                 eta: float = ETA, w_max: float = W_MAX) -> int:
    """
    Strengthen edges traversed in path.
    Activation = cosine similarity between node embeddings.
    Returns count of edges strengthened or created.
    """
    updated = 0
    for i in range(len(path) - 1):
        a, b = path[i], path[i + 1]

        e_a = G.nodes[a]["embedding"]
        e_b = G.nodes[b]["embedding"]
        sim = float(1.0 - cosine_dist(e_a, e_b))
        delta = eta * max(sim, 0.01)  # minimum delta even for dissimilar nodes

        if G.has_edge(a, b):
            G[a][b]["weight"] = min(G[a][b]["weight"] + delta, w_max)
        else:
            G.add_edge(a, b, weight=min(delta, w_max))

        updated += 1

    return updated


# ─────────────────────────────────────────────
# DECAY (forgetting)
# ─────────────────────────────────────────────

def decay_graph(G: nx.Graph, lambda_: float = LAMBDA,
                theta: float = THETA) -> int:
    """
    Exponential decay on all edge weights.
    Prune edges that fall below theta.
    Returns count of pruned edges.
    """
    for u, v, data in G.edges(data=True):
        data["weight"] *= (1.0 - lambda_)

    weak = [(u, v) for u, v, d in G.edges(data=True) if d["weight"] < theta]
    G.remove_edges_from(weak)
    return len(weak)


# ─────────────────────────────────────────────
# NORMALIZATION (guard against hub collapse)
# ─────────────────────────────────────────────

def normalize_weights(G: nx.Graph, method: str = "global"):
    """
    Prevent a few edges from monopolizing navigation.
    method='global': divide all weights by global max
    method='node':   per-node normalization (preserves relative strengths)
    """
    weights = [d["weight"] for _, _, d in G.edges(data=True)]
    if not weights:
        return

    if method == "global":
        w_max = max(weights)
        if w_max > 0:
            for u, v, data in G.edges(data=True):
                data["weight"] /= w_max

    elif method == "node":
        for node in G.nodes:
            nbrs = list(G.neighbors(node))
            if not nbrs:
                continue
            total = sum(G[node][nb]["weight"] for nb in nbrs)
            if total > 0:
                for nb in nbrs:
                    G[node][nb]["weight"] /= total


# ─────────────────────────────────────────────
# SNAPSHOT METRICS (structural state of the graph)
# ─────────────────────────────────────────────

def graph_snapshot(G: nx.Graph, epoch: int) -> dict:
    """
    Capture structural state for drift analysis.
    """
    weights = np.array([d["weight"] for _, _, d in G.edges(data=True)])
    pr = nx.pagerank(G, weight="weight") if len(G.edges) > 0 else {}
    pr_vals = np.array(list(pr.values()))

    # crystallized edges: weight > 0.5 (normalized scale)
    crystal_count = int(np.sum(weights > 0.5)) if len(weights) > 0 else 0

    # hub concentration: entropy of PageRank distribution
    if len(pr_vals) > 0:
        pr_norm = pr_vals / (pr_vals.sum() + 1e-12)
        hub_entropy = float(-np.sum(pr_norm * np.log(pr_norm + 1e-12)))
    else:
        hub_entropy = 0.0

    return {
        "epoch":           epoch,
        "n_edges":         len(G.edges),
        "n_nodes":         len(G.nodes),
        "w_mean":          float(np.mean(weights)) if len(weights) > 0 else 0.0,
        "w_std":           float(np.std(weights))  if len(weights) > 0 else 0.0,
        "w_max":           float(np.max(weights))  if len(weights) > 0 else 0.0,
        "crystal_edges":   crystal_count,
        "hub_entropy":     hub_entropy,
    }


# ─────────────────────────────────────────────
# STRUCTURAL DRIFT (H6 metric)
# ─────────────────────────────────────────────

def structural_drift(G_current: nx.Graph, pr_baseline: dict) -> float:
    """
    KL divergence between current PageRank distribution and baseline.
    Measures how much the graph has structurally drifted.
    D_KL(P_t || P_0) — high value = significant drift.
    """
    if len(G_current.edges) == 0 or not pr_baseline:
        return 0.0

    pr_t = nx.pagerank(G_current, weight="weight")

    nodes = set(pr_t) & set(pr_baseline)
    if len(nodes) < 2:
        return 0.0

    p = np.array([pr_t[n] for n in nodes])
    q = np.array([pr_baseline[n] for n in nodes])

    p = p / (p.sum() + 1e-12)
    q = q / (q.sum() + 1e-12)

    return float(np.sum(p * np.log((p + 1e-12) / (q + 1e-12))))


# ─────────────────────────────────────────────
# TDA — NARRATIVE CRYSTALLIZATION (H7)
# ─────────────────────────────────────────────

def tda_h1_persistence(G: nx.Graph) -> dict:
    """
    Compute H1 (1-cycles) persistence using Gudhi Rips complex
    on node embeddings. Persistent H1 = stable narrative loops.

    Returns:
        loops: count of H1 features with persistence > threshold
        max_persistence: strongest loop found
        betti_1: total H1 features detected
    """
    try:
        import gudhi
    except ImportError:
        return {"loops": 0, "max_persistence": 0.0, "betti_1": 0, "available": False}

    if len(G.nodes) < 3:
        return {"loops": 0, "max_persistence": 0.0, "betti_1": 0, "available": True}

    points = np.array([G.nodes[n]["embedding"] for n in G.nodes])

    # Rips complex up to dimension 2
    rips = gudhi.RipsComplex(points=points, max_edge_length=1.5)
    st   = rips.create_simplex_tree(max_dimension=2)
    st.compute_persistence()

    h1 = [(b, d) for dim, (b, d) in st.persistence()
          if dim == 1 and d != float("inf")]

    if not h1:
        return {"loops": 0, "max_persistence": 0.0, "betti_1": 0, "available": True}

    persistences = [d - b for b, d in h1]
    threshold = 0.1  # minimum persistence to count as "significant"

    return {
        "loops":           int(sum(p > threshold for p in persistences)),
        "max_persistence": float(max(persistences)),
        "betti_1":         len(h1),
        "available":       True,
    }
