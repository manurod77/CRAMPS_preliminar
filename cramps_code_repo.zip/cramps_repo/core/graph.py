"""
core/graph.py — CRAMPS v0.5
Graph construction and attractor computation.
"""

import networkx as nx
import numpy as np
from scipy.spatial.distance import cosine as cosine_dist


def build_graph(units: list[str], embeddings: np.ndarray,
                threshold: float = 0.35) -> nx.Graph:
    """
    Build undirected weighted graph from narrative units.
    Edge weight = cosine similarity, only if > threshold.
    """
    G = nx.Graph()
    for idx, text in enumerate(units):
        G.add_node(idx, text=text, embedding=embeddings[idx])

    n = len(units)
    for i in range(n):
        for j in range(i + 1, n):
            sim = 1.0 - cosine_dist(embeddings[i], embeddings[j])
            if sim > threshold:
                G.add_edge(i, j, weight=float(sim))

    return G


def compute_attractors(G: nx.Graph) -> dict:
    """
    PageRank as attractor strength.
    Structural importance — not lexical frequency.
    """
    if len(G.edges) == 0:
        return {n: 0.0 for n in G.nodes}
    return nx.pagerank(G, weight="weight")
